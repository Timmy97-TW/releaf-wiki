# Inline Photometer — 獨立 App

**Arduino UNO Q + Arduino App Lab** ｜ 韌體 `photometer-fw v1.2.0` ｜ 後端 `photometer-py v1.2.0` ｜ 網頁 UI v1.2.0

從 ReLeaf Perfusion HFB 整合版（App v4.9.2 / FW v3.10.3）擷取 OD600 光度計部分，單獨成一個 App。**接線與整合版相同。**

### v1.2.0 架構：MCU 只讀原始值，演算法全部在 Python

```
MCU (sketch.ino)                         Linux (python/)
─────────────────                        ───────────────────────────────────────────────
量測時序：4 暗 → LED 亮 → 16 亮            photometer_algos.py  ← main.py 與 tools/replay.py 共用
硬體檢查：成功讀值夠不夠、有沒有卡住          8 種估計演算法 + 氣泡比例 + blank + OD（dual / single）
  不夠 / 卡住 → 重設 I2C、同次量測內重試     每次量測 8 種同時算，各自有自己的 blank
on_od_raw ── 每次嘗試的全部原始讀值 ──────→  main.py：主要演算法決定顯示的 OD 與有效性；全部寫進 CSV
         ←── trigger_measurement ─────────  氣泡過多 → 立刻要求重量一次
```

- **換演算法不用重新燒錄**：網頁選了就生效，目前讀值立刻用最後一次原始讀值重算。
- **曲線圖同時畫 8 種演算法**（粗線 = 主要演算法），可個別開關；CSV 也每列都有 8 種的 `od_<演算法>`。
- MCU 只剩讀取，量測不會再被演算法拖慢；也不再需要「先顯示粗略值」。
- blank 存在 Linux 端，MCU 重開不會遺失。

---

## 1. 接線

| 元件 | 接到 | 備註 |
|---|---|---|
| 光源 LED | D3 → 1.2 kΩ → 2N2222 Base（Base 另接 10 kΩ 到 GND） | 低邊開關；只在量測時點亮 |
| BH1750 #1（sample） | I2C **0x5C**（ADDR → 3V3） | |
| BH1750 #2（reference） | I2C **0x23**（ADDR → GND） | 單光路模式可以不接 |
| I2C | SDA → **D20**、SCL → **D21** | GY-302 建議接 UNO Q 的 **3.3 V** |

全部由 UNO Q 供電。需要的 Sketch Library：**Arduino_RouterBridge**。需要的 Brick：**WebUI - HTML**（`assets/libs/` 要從舊 App 複製，或移除再加回 Brick）。

---

## 2. 光路模式（網頁「🔆 光路模式」）

| 模式 | 用在 | OD 怎麼算 | 額外檢查 |
|---|---|---|---|
| **光纖**（預設） | 兩條光纖分別送光，比例不固定 | `log10(blank S/R ÷ 目前 S/R) × 光程長係數` | reference 相對 blank 偏移（`ref_rel`） |
| **分光鏡** | 固定比例分光；由使用者輸入「Sample 份數 : Reference 份數」 | 同光纖（以空白校正為準） | 同上，另外拿分光比檢查**空白**與**對光**時的 S/R |
| **單光路** | 只有 sample 一條光路 | `log10(blank S ÷ 目前 S) × 光程長係數` | reference 的警告、欄位全部隱藏；reference 可以不接 |

- **分光鏡為什麼不用分光比直接算 OD？** 兩顆 BH1750 的響應、分光鏡實際分光比都和標稱值有出入，空白校正量到的比值才準。分光比拿來做「對位有沒有跑掉」的檢查：空白或對光時的 S/R 落在「分光比 ÷2～×2」以外就警告（容許範圍在 `constants.json` 的 `splitter_ratio_tolerance`）。
- 範例：1:9 分光鏡，9 份給 sample → 輸入 **9 : 1**。
- 光路模式存在 Linux 端（`calibration_state.json`），MCU 只收到 `ref_mode`（0 = 雙光路、1 = 單光路，單光路時 MCU 不要求 reference 的讀值有效）。換模式不用重新校正空白，但 OD 的意義變了（雙光路 ↔ 單光路），CSV 的 event 欄會記下切換。
- 兩種 OD（dual、single）每次都同時算、同時記在 CSV，可以事後比較。

---

## 3. 感測器設定（v1.1.0 起固定，不再調增益）

兩顆 BH1750 固定 **MTreg 69 + 高解析模式 2**：每筆轉換約 120 ms（讀取間隔 130 ms），0.5 lx/count。模式 2 跟預設的模式 1 一樣快、計數多一倍，光弱時等於免費多一倍解析度；代價是滿刻度降到約 27,300 lx（等效）。

要改的話在 `sketch.ino` 的 `FIXED_MT` / `FIXED_H2`：
- 飽和 → `FIXED_H2 = false`
- 光太弱、想要更多計數 → 把 `FIXED_MT` 調高（最大 254，靈敏度 ×3.7，但每筆約 0.5 秒，一次量測約 10 秒）

讀值一律換算成等效 lux，改這兩個常數不改變 OD 的定義，但改完要重新校正空白。

---

## 4. 演算法（v1.2.0 起在 Python 計算）

| 名稱 | 做法 | 適合 |
|---|---|---|
| `mad` | 中位數 ± 3·MAD 閘門內平均 | 少量隨機離群 |
| `qn` | Rousseeuw–Croux Qn 尺度的閘門 | 同上，對偏斜分布較穩 |
| `biweight` | Tukey biweight（c = 4.685） | 同上 |
| `upper`（預設） | 單邊：只剔除過低值（氣泡遮光），取中位數以上平均 | 氣泡 < 50% |
| `mean` | 直接平均，不剔除 | 對照組 |
| `median` | 中位數 | 對照組 |
| `p75` / `p90` | 第 75 / 90 百分位（上包絡） | 氣泡很多時最穩，但雜訊略大、在無氣泡時有一點正偏 |

- 亮燈前 2 筆丟掉（LED 穩定期）；讀取失敗（−1）一律排除；成功讀值 < 8 筆判無效。
- **氣泡比例**（與演算法無關）：亮燈讀值中比上包絡 P90 低 5% 以上的比例（`constants.json` 的 `bubble_drop_pct`）。超過 50% → **所有演算法都判無效**、旗標 `bubbles`。原因：氣泡佔多數時中位數類方法會把氣泡當成真值，而且自己的拒收率是 0，會「安靜地錯」。
- **氣泡重量**：氣泡比例或主要演算法的拒收率 > 50% 且無效 → Python 立刻呼叫 `trigger_measurement` 再量一次（每次最多一次，`bubble_retry` 可關）。
- 模擬（OD 0.6，35% 讀值有氣泡、氣泡讓光少 40%）：`upper` 最大誤差 0.010，`mean` 0.48。氣泡 70% 時只有 `p90` 還對，其他全部被氣泡門檻判無效。

---

## 5. 原始讀值記錄與離線重跑

**錄製時會產生兩個檔：**

| 檔案 | 內容 |
|---|---|
| `photometer_<時間>[_標籤].csv` | 每次量測一列（主要演算法的 OD、各種衍生量、旗標、事件，加上 8 種演算法各自的 `od_*`、`rej_*`） |
| `photometer_<時間>[_標籤]_raw.csv` | 每次**嘗試**一列：暗電流 4 筆 + 亮燈 16 筆，sample 與 reference 兩通道，全部是原始計數 |

- 開始錄製時，會先把「最近一次空白校正」的原始讀值寫進 raw 檔（`blank_measure = 1`），離線重跑才有 blank。**建議流程：先校正空白，再開始錄製。**
- MCU 在讀取失敗太多或讀值卡住時會重試一次，所以同一個 `meas_seq` 可能有兩列（`attempt` = 0、1；`final` = 1 是最後一次，`hw_ok` = 硬體層有效）。氣泡重量則是新的 `meas_seq`。
- 讀取失敗的值記為 −1；亮燈前 2 筆是 LED 穩定期，演算法會丟掉（raw 檔照樣保留）。

**離線重跑**（電腦上有 Python 3.8+ 即可，不需要額外套件）：

```bash
python3 tools/replay.py photometer_20261010_101500_run1_raw.csv
python3 tools/replay.py run1_raw.csv --reference 0.80 --threshold 0.05   # 標準品實驗：已知真實 OD
python3 tools/replay.py run1_raw.csv --mode single --plf 5 --out compare.csv
```

`replay.py` 和 App 用的是同一份 `python/photometer_algos.py`（放在 App 資料夾裡直接就找得到；單獨拷出去時把這個檔放在 `replay.py` 旁邊）。對同一批原始讀值重跑 8 種演算法，再各做一次 Hampel 濾波，輸出逐筆對照 CSV，並印出每種方法的 n、平均、SD、無效率；給了 `--reference` 再加上偏差、RMSE、失敗率，以及 **silent failure 率**（讀數錯了卻會被判為有效的比例）。預設每次量測依它自己記錄的 `ref_mode` 算（錄製中途切換光路也對）。

驗證過：重跑結果與 App 當場寫進 CSV 的 8 種 `od_*` 一致（差 ≤ 1e-5，只是四捨五入）。

---

## 6. 部署

1. App Lab 新建 App，放入 `app.yaml`、`sketch/`、`python/`（**v1.2.0 多了 `photometer_algos.py`，一定要放**）、`assets/index.html`；`tools/` 是給電腦用的，放不放都可以。
2. 加入 Brick **WebUI - HTML**，補齊 `assets/libs/`。
3. 加入 Sketch Library **Arduino_RouterBridge**。
4. Run。Console 應出現：
   ```
   [boot] Inline photometer photometer-fw v1.2.0 (raw acquisition only), Bridge.begin=OK
   [boot] step 1/4: get_diag registered
   [boot] step 2/4: I2C probe 0x5C / 0x23
   [boot]   sample    0x5C: ok (0 ms)
   [boot]   reference 0x23: ok (0 ms)
   [boot] step 3/4: BH1750 init (fixed MTreg 69, H-res mode 2, read every 130 ms)
   [boot] step 4/4: Bridge functions registered
   ```
   I2C 探測結果：`ok`；`nak` = 匯流排正常但該位址沒裝置（沒供電或 ADDR 接錯）；`timeout` = 匯流排沒回應（SDA/SCL 被拉低、短路、沒上拉、GND 沒接）。失敗的感測器每 10 秒自動重試，接線修好就恢復。

---

## 7. 使用流程

1. **選光路模式**；分光鏡要輸入分光比。
2. **對光**：進入對光模式（LED 恆亮），讓讀值盡量高但不要到 100%。分光鏡模式會即時顯示「相對分光比」。
3. **空白校正**：流通池裝乾淨培養基，按「校正空白」。
4. **開始錄製**，需要時加事件備註。
5. **選主要演算法**（量測設定）：一選就生效。曲線下方的方塊顯示每種演算法目前的 OD 與剔除率，點方塊開關該演算法的曲線；紅字 = 該演算法判這次無效。

光路（光纖、分光鏡對位）每次被動過，都要重新校正空白。單光路沒有 reference 補償 LED 漂移，建議更常校正。

---

## 8. CSV 欄位

**主檔**：`timestamp_iso, epoch_s, elapsed_s, dt_s, meas_seq, attempts, od600, od_dual, od_single, od_alg, optical_mode, splitter_ratio, transmittance_pct, lux_sample, lux_ref, sr_ratio, blank_ratio, blank_lux_sample, blank_lux_ref, ref_rel, sample_rel, counts_sample, counts_ref, bubble_pct, bubble_frac_pct, valid, blank_set, flag_text, path_length_factor, od_mad … od_p90, rej_mad … rej_p90, event`

- `od600` / `valid` / `bubble_pct` 是主要演算法（`od_alg`）的值；`bubble_frac_pct` 是與演算法無關的氣泡比例。
- blank 欄位是主要演算法的 blank。

**raw 檔**：`timestamp_iso, epoch_s, meas_seq, attempt, final, hw_ok, stuck, blank_measure, t0_ms, period_ms, mtreg, hres_mode, lux_per_count, ref_mode, optical_mode, dark_s_0..3, dark_r_0..3, lit_s_0..15, lit_r_0..15`

**旗標**（`flag_text`）：`sat_s` `sat_r`（飽和）、`low_s` `low_r`（訊號低）、`i2c_s` `i2c_r`（成功讀值不足）、`stuck_s` `stuck_r`（讀值卡住）、`no_od`、`bubbles`（氣泡過半）、`ref_drift`、`split_ratio_off`。單光路模式下 reference 相關旗標不顯示。

---

## 9. Bridge 介面（MCU）

| 函式 | 說明 |
|---|---|
| `get_diag()` | `loop_max_us,od_state,reinit_step,uptime_ms,boot_stage,i2c=S:..\|R:..,rc=S:..\|R:..\|B:..,io=S:slow/pause/fail\|R:..,fw`（`Bridge.provide`，setup 一開始就註冊） |
| `trigger_measurement()` | `queued` / `busy` |
| `get_last_raw()` | 最近一次完成量測的 final 嘗試（格式同 `on_od_raw`）+ `,age_ms=..,busy=0\|1` |
| `set_config(kv)` / `get_config()` | 只剩 `interval_s`（5–86400）、`ref_mode`（0/1）；get 另回傳 `mt,h2,period_ms,lpc` |
| `set_dev_mode(0\|1)` / `get_dev_readings()` | 對光模式；`dev,raw_s,raw_r,lux_s,lux_r` |
| `reinit_sensors()` | 重置 I2C 並重新初始化兩顆，回傳 `S:ok\|R:ok` |

主動推送：`on_od_raw`（每次嘗試）：`seq,att,final,hw_ok,stuck=S|R|SR|-,t0,per,mt,h2,lpc,ref_mode,ds=4 筆,dr=4 筆,ls=16 筆,lr=16 筆`（`|` 分隔，讀取失敗 = −1）。

v1.1.x 的 `get_od_data`、`get_blank_info`、`calibrate_blank`、`set_blank_manual`、`clear_blank`、`on_od600_update`、`on_blank_result`、`on_od_live` 都移除了（blank 與 OD 在 Python）。

---

## 10. 版本

| 版本 | 內容 |
|---|---|
| v1.2.0 | **MCU 只讀原始值，演算法全部移到 Python**（新檔 `python/photometer_algos.py`，與 `tools/replay.py` 共用）；8 種演算法同時計算、各自有 blank，曲線圖可同時顯示並個別開關，CSV 每列記錄全部 8 種；主要演算法一選就生效並立刻重算；新增與演算法無關的氣泡比例門檻（過半 → 全部無效 + 立刻重量）；blank 改存在 Linux 端；移除「先顯示粗略值」；讀值卡住時在同一次量測內重置 I2C 並重試（原本要等兩次量測）；v1.1.x 的 blank 存檔自動轉入（標成手動，請重新校正） |
| v1.1.3 | 修正「不合理的低讀值」：讀取失敗（−1）不再被當成讀值送進演算法，成功讀值不足 8 筆判為無效；重試時優先採用有效的那次；亮燈期間每 4 筆推一次即時讀值（未經演算法），網頁先顯示、量完再換成正式結果；網頁顯示 MCU loop 最長耗時。`tools/replay.py` 同步 |
| v1.1.2 | 修正「讀數斷斷續續、一斷十幾秒」：I2C 逾時保護改成連續 3 次慢操作才暫停、只暫停 2 秒，每次慢操作都印在 Console 並計數（`get_diag` 的 `io=`，網頁量測設定面板顯示）；量測間隔改成開始到開始 |
| v1.1.1 | 修正「讀值變成 0、要重開程式才恢復」：每次量測前重送量測模式；亮燈讀值卡住（全 0 或固定）→ 旗標 `stuck_s/stuck_r` 並自動重新初始化，再卡住就重置 I2C 控制器；網頁「重新初始化感測器」按鈕；`get_diag` 回報重新初始化次數 |
| v1.1.0 | 原始讀值記錄（raw CSV）+ `tools/replay.py`；光路模式（光纖／分光鏡＋分光比／單光路）；移除通道增益與自動增益，感測器固定 MTreg 69 + 模式 2；單光路時拒收率與空白檢查只看 sample |
| v1.0.2 | I2C 只探測兩個位址並計時（不再掃 126 個位址）；匯流排逾時保護；失敗感測器自動重試 |
| v1.0.1 | `get_diag` 最先註冊並回報開機進度 |
| v1.0.0 | 從整合版擷取；光纖版：每通道增益與自動增益、飽和偵測、dual/single、對光工具、raw-less CSV |

---

## 11. 疑難排解：讀值是 0

BH1750 若因電源瞬間掉壓（內部重置）、匯流排雜訊收到錯誤指令等原因離開量測模式，它**仍然會回應 I2C**，只是送回 0 或一直是同一個舊值。v1.1.0 以前只有「讀取失敗」才會重新初始化，所以會一直停在 0，直到重開程式。v1.1.1 起每次量測前都重送量測模式；v1.2.0 起讀值卡住時在同一次量測內重置 I2C 控制器並重試，網頁也有手動按鈕。

如果 Console 一直出現 `sensor stuck` 或網頁的重新初始化次數持續增加，代表根本原因還在，常見的是：
- GY-302 的 3.3 V 供電不穩：在模組 VCC–GND 就近加 10 µF + 100 nF 電容；LED 不要跟感測器共用同一條細電源線。
- I2C 線太長或與 LED / 馬達線並行：縮短、絞線、遠離切換電流的線。
- 杜邦線接觸不良：光纖調整時碰到線材就會發生。

raw 檔可以幫忙判斷：卡住時 `lit_s_*` 全是 0（感測器被重置）或全是同一個數字（停止轉換）；讀取失敗則是 −1。

## 12. 已知限制

- 氣泡門檻（比上包絡低 5%）是依模擬設定的；實際氣泡讓光少多少要看流通池，請用 raw 檔確認後調 `bubble_drop_pct`。該用哪一種演算法，也請用 raw 檔 + replay 在你的流通池上驗證。
- 8 種演算法共用同一次空白量測；手動輸入的 blank 8 種共用同一個值。
- 這個 App 與整合版不能同時跑在同一塊板子上。
- v1.2.0 的韌體與 Python 必須一起更新（舊 sketch 會被網頁標示版本不符）。**尚未在實機上燒錄測試**；第一次上板請看 Console 的 `[boot]` 與 `[photo]` 訊息。
