#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Inline Photometer — 原始讀值離線重跑 (replay)
==============================================
讀入錄製產生的 <檔名>_raw.csv, 用「同一批原始讀值」重跑全部演算法與 Hampel 濾波, 輸出逐筆對照表,
並印出每種方法的統計摘要。演算法與 App 共用 ../python/photometer_algos.py, 結果與即時計算一致。

只用 Python 標準函式庫(3.8+):

    python3 replay.py photometer_20261010_101500_run1_raw.csv
    python3 replay.py run_raw.csv --reference 0.80 --threshold 0.05     # 已知真實 OD(例如標準品)
    python3 replay.py run_raw.csv --mode single --plf 5 --out compare.csv
    python3 replay.py run_raw.csv --blank-s 812.4 --blank-r 433.7        # raw 檔裡沒有 blank 時手動給

放置: 這個檔案在 tools/, 演算法模組在 python/photometer_algos.py(同一個 App 資料夾裡)。
若把 replay.py 單獨拷到別處, 把 photometer_algos.py 放在同一個資料夾也可以。

注意:
  - 同一次量測可能有兩次嘗試(MCU 因讀取失敗或讀值卡住而重試); 每種演算法各自挑「有效、再比拒收率」。
  - blank 預設取這次量測之前最近一次空白校正的原始讀值(blank_measure=1), 每種演算法用自己算出的 blank。
  - App 因為「主要演算法」拒收率 > 50% 而要求的重量, 在 raw 檔裡是一次新的量測(新的 meas_seq)。
"""

import argparse
import csv
import math
import os
import statistics
import sys

_here = os.path.dirname(os.path.abspath(__file__))
for p in (_here, os.path.join(_here, "..", "python")):
    if os.path.exists(os.path.join(p, "photometer_algos.py")):
        sys.path.insert(0, p)
        break
import photometer_algos as PA  # noqa: E402

N_DARK, N_LIT = 4, 16


def load_raw(path):
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            try:
                rows.append({
                    "epoch": float(r["epoch_s"]), "seq": int(r["meas_seq"]), "att": int(r["attempt"]),
                    "final": r.get("final", "1") == "1",
                    "hw_ok": r.get("hw_ok", "1") == "1",
                    "blank": int(r.get("blank_measure", "0") or 0) == 1,
                    "lpc": float(r["lux_per_count"]), "ref_mode": int(r["ref_mode"]),
                    "ds": [float(r[f"dark_s_{i}"]) for i in range(N_DARK)],
                    "dr": [float(r[f"dark_r_{i}"]) for i in range(N_DARK)],
                    "ls": [float(r[f"lit_s_{i}"]) for i in range(N_LIT)],
                    "lr": [float(r[f"lit_r_{i}"]) for i in range(N_LIT)],
                })
            except (KeyError, ValueError) as e:
                print(f"[skip] 無法解析的列: {e}", file=sys.stderr)
    return rows


def group_measurements(rows):
    """依時間順序分組; 同一個 seq 的後續嘗試(att > 0)併入前一組。MCU 重開後 seq 會重來, 所以不能只看 seq。"""
    groups = []
    for r in sorted(rows, key=lambda x: x["epoch"]):
        if groups and groups[-1][0]["seq"] == r["seq"] and r["att"] > 0:
            groups[-1].append(r)
        else:
            groups.append([r])
    return groups


def main():
    ap = argparse.ArgumentParser(description="Replay photometer raw readings with all algorithms.")
    ap.add_argument("raw_csv")
    ap.add_argument("--plf", type=float, default=5.0, help="光程長係數(預設 5.0)")
    ap.add_argument("--mode", choices=["auto", "dual", "single"], default="auto",
                    help="auto = 每次量測依它自己記錄的 ref_mode(錄製中途切換光路也正確)")
    ap.add_argument("--blank-s", type=float, help="raw 檔裡沒有 blank 時手動給 sample lux")
    ap.add_argument("--blank-r", type=float, help="raw 檔裡沒有 blank 時手動給 reference lux(雙光路)")
    ap.add_argument("--reference", type=float, help="已知真實 OD(標準品實驗), 用來算偏差/RMSE/silent failure")
    ap.add_argument("--threshold", type=float, default=0.05, help="誤差超過多少 OD 算失敗(預設 0.05)")
    ap.add_argument("--hampel-window", type=int, default=7)
    ap.add_argument("--hampel-k", type=float, default=3.0)
    ap.add_argument("--out", help="輸出逐筆對照 CSV(預設 <raw>_replay.csv)")
    a = ap.parse_args()

    rows = load_raw(a.raw_csv)
    if not rows:
        sys.exit("raw 檔沒有資料")
    groups = group_measurements(rows)
    forced = None if a.mode == "auto" else (a.mode == "single")
    names = PA.ALG_NAMES
    manual = {"s": a.blank_s or 0.0, "r": a.blank_r or 0.0} if (a.blank_s or a.blank_r) else None
    blanks = {n: manual for n in names}

    table = []
    for g in groups:
        is_blank = g[0]["blank"]
        single = forced if forced is not None else (g[-1]["ref_mode"] == 1)
        row = {"epoch": g[0]["epoch"], "seq": g[0]["seq"], "attempts": len(g), "blank_measure": int(is_blank),
               "mode": "single" if single else "dual"}
        for n in names:
            res = PA.measurement_result(g, n, single)
            if is_blank:
                blanks[n] = {"s": res["S"], "r": res["R"]}
                od = 0.0
            else:
                dual, sing = PA.od_values(res, blanks[n], a.plf)
                od = sing if single else dual
            row[f"od_{n}"] = od
            row[f"rej_{n}"] = res["rej"]
            row[f"bad_{n}"] = int(not res["ok"])
        table.append(row)

    data_rows = [r for r in table if not r["blank_measure"]]
    for n in names:
        filt = PA.hampel([r[f"od_{n}"] for r in data_rows], a.hampel_window, a.hampel_k)
        for r, v in zip(data_rows, filt):
            r[f"od_{n}_hampel"] = v

    out = a.out or a.raw_csv.rsplit(".", 1)[0] + "_replay.csv"
    cols = ["epoch", "seq", "attempts", "blank_measure", "mode"] + [f"{p}_{n}" for n in names for p in ("od", "rej", "bad")] \
        + [f"od_{n}_hampel" for n in names]
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in table:
            w.writerow({k: ("" if r.get(k) is None else (f"{r[k]:.5f}" if isinstance(r.get(k), float) else r.get(k)))
                        for k in cols})

    n_blank = sum(r["blank_measure"] for r in table)
    print(f"檔案: {a.raw_csv}")
    modes = sorted({r["mode"] for r in data_rows})
    print(f"模式: {'/'.join('單光路' if m == 'single' else '雙光路' for m in modes) or '-'}"
          f"{'(依各次量測記錄)' if forced is None else '(強制)'}  光程長係數: {a.plf}  量測: {len(data_rows)} 次  blank: {n_blank} 次"
          + ("" if n_blank or manual else "  ⚠️ 沒有 blank, OD 無法計算(用 --blank-s / --blank-r 指定)"))
    if a.reference is not None:
        print(f"參考值 OD = {a.reference}, 失敗門檻 |誤差| > {a.threshold}")
    print()
    hdr = f"{'method':<18}{'n':>5}{'mean':>10}{'SD':>9}{'invalid%':>10}"
    if a.reference is not None:
        hdr += f"{'bias':>9}{'RMSE':>9}{'fail%':>8}{'silent%':>9}"
    print(hdr)
    print("-" * len(hdr))
    for n in names:
        for suffix in ("", "_hampel"):
            vals = [(r[f"od_{n}{suffix}"], r[f"bad_{n}"]) for r in data_rows if r.get(f"od_{n}{suffix}") is not None]
            if not vals:
                continue
            ods = [v[0] for v in vals]
            line = (f"{n + suffix:<18}{len(ods):>5}{statistics.fmean(ods):>10.4f}"
                    f"{(statistics.stdev(ods) if len(ods) > 1 else 0):>9.4f}{100 * sum(v[1] for v in vals) / len(vals):>10.1f}")
            if a.reference is not None:
                err = [o - a.reference for o in ods]
                fail = [abs(e) > a.threshold for e in err]
                silent = [f and not bad for f, (_, bad) in zip(fail, vals)]     # 錯了卻會被判為有效
                line += (f"{statistics.fmean(err):>9.4f}{math.sqrt(statistics.fmean([e * e for e in err])):>9.4f}"
                         f"{100 * sum(fail) / len(fail):>8.1f}{100 * sum(silent) / len(silent):>9.1f}")
            print(line)
    print(f"\n逐筆對照已寫到: {out}")


if __name__ == "__main__":
    main()
