/*
  ============================================================================
  Inline Photometer — 獨立版 MCU Sketch (Arduino UNO Q / STM32U585 + Zephyr, App Lab)
  ============================================================================
  接線(與 ReLeaf 整合版相同, 全部由 UNO Q 供電):
    - 光源 LED   : D3 → 1.2kΩ → 2N2222 Base (10kΩ 下拉到 GND), 低邊開關, 只在量測時點亮
    - sample     : BH1750 (GY-302) I2C 0x5C (ADDR → 3V3)
    - reference  : BH1750 (GY-302) I2C 0x23 (ADDR → GND)   ※ 單光路模式可以不接
    - I2C        : D20 (SDA) / D21 (SCL)

  需要的 Sketch Library: Arduino_RouterBridge(BH1750 驅動已內嵌)

  === v1.2.0 (2026-10-10): MCU 只負責讀原始值 ===
  所有演算法(穩健估計、暗電流扣除、blank、OD、單/雙光路)都搬到 Linux 端 Python。MCU 只做:
    1. 量測時序: 4 筆暗電流 → LED 亮 + 60 ms → 16 筆亮燈 → 關燈, 每筆間隔 130 ms
    2. 硬體層的有效性: 亮燈成功讀值夠不夠(>= 8 筆)、讀值有沒有卡住 —— 不夠或卡住就自動重試一次,
       並重新初始化感測器 / 重置 I2C(這些是硬體問題, 必須在 MCU 就地處理)
    3. 把每次嘗試的全部原始讀值用 on_od_raw 推給 Python
  好處: 換演算法不必重新燒錄; Python 可以對同一筆資料同時算所有演算法並一起畫在曲線上。
  (氣泡拒收率過高的重試改由 Python 決定: 它會再呼叫一次 trigger_measurement。)

  沿用 v1.1.x 的硬體處理:
    - 每次量測前重送 Power On + 量測模式(感測器被重置 / 掉壓後自動回到量測模式)
    - 亮燈讀值全部相同(全 0 或固定值)→ 卡住 → 立刻重置 I2C 控制器 + 重新設定兩顆, 同一次量測內重試
      (v1.2.0 起不再「先 reinit、下次量測才重置」, 實測模擬中控制器卡住要拖兩次量測才恢復)
    - I2C 連續 3 次慢操作才暫停該感測器 2 秒; 每次慢操作印在 Console 並計數
    - 開機只探測兩個位址(ok / nak / timeout), get_diag 最先註冊
    - 量測間隔「開始到開始」

  對外提供 (Bridge.provide_safe, String → String):
    trigger_measurement()  -> "queued" / "busy"
    get_last_raw()         -> 最近一次完成量測的 raw payload(同 on_od_raw, final=1) + ",age_ms=..,busy=0|1"
                              (Python 重啟或漏收 notify 時補值用)
    set_config(kv)         -> "interval_s=..,ref_mode=0|1"; 回傳 get_config() 或 "rejected:<原因>"
    get_config()           -> "interval_s=..,ref_mode=..,mt=..,h2=..,period_ms=..,lpc=.."
    set_dev_mode(on)       -> "1"/"0"  對光模式: LED 恆亮, 暫停自動量測
    get_dev_readings()     -> "dev,raw_s,raw_r,lux_s,lux_r"(即時未濾波, 未扣暗電流; 失敗為 -1)
    reinit_sensors()       -> 手動重置 I2C + 兩顆重新初始化, 回傳 "S:ok|R:ok" 或 "busy"
  (Bridge.provide, setup() 一開始就註冊)
    get_diag()             -> "loop_max_us,od_state,reinit_step,uptime_ms,boot_stage,i2c=S:..|R:..,
                               rc=S:n|R:n|B:n,io=S:slow/blk/fail|R:..,FW_VERSION"

  主動推送 (Bridge.notify):
    on_od_raw(payload)  每一次嘗試結束時一筆:
      "seq=..,att=..,final=0|1,hw_ok=0|1,stuck=S|R|SR|-,t0=..,per=..,mt=..,h2=..,lpc=..,ref_mode=..,
       ds=a|b|c|d,dr=..,ls=16 筆,lr=16 筆"
      final=1 代表這是這次量測的最後一次嘗試(Python 收到才開始計算); 讀取失敗記為 -1。
  ============================================================================
*/

#include <Wire.h>
#include <Arduino_RouterBridge.h>
#include <math.h>
#include <string.h>

#define FW_VERSION "photometer-fw v1.2.0"

extern "C" int *__errno(void) {
  static int photometer_dummy_errno = 0;
  return &photometer_dummy_errno;
}

// ===========================================================================
// 小工具
// ===========================================================================
bool kvGet(const String &s, const char *key, float &out) {
  String k = String(key) + "=";
  int start = 0;
  int len = s.length();
  while (start < len) {
    int end = s.indexOf(',', start);
    if (end < 0) end = len;
    String tok = s.substring(start, end);
    tok.trim();
    if (tok.startsWith(k)) {
      String v = tok.substring(k.length());
      v.trim();
      if (v.length() == 0) return false;
      out = v.toFloat();
      return !isnan(out);
    }
    start = end + 1;
  }
  return false;
}

// ===========================================================================
// 一、BH1750 驅動(內嵌) — 固定設定
// ===========================================================================
// 兩顆感測器固定: MTreg 69 + 連續高解析模式 2(0.5 lx/count, 每筆轉換約 120 ms)。
// 飽和就把 FIXED_H2 改成 false; 光太弱可把 FIXED_MT 調高(最大 254, 每筆約 0.5 秒)。
const uint8_t FIXED_MT  = 69;
const bool    FIXED_H2  = true;
const uint8_t MT_DEFAULT = 69;
const float   RAW_SATURATED = 65535.0f;
const float   LUX_PER_COUNT = 1.0f / (1.2f * (FIXED_MT / (float)MT_DEFAULT) * (FIXED_H2 ? 2.0f : 1.0f));
const unsigned long I2C_READ_TIMEOUT_MS = 3;
const uint16_t SAMPLE_PERIOD_MS = (uint16_t)(130.0f * FIXED_MT / MT_DEFAULT + (FIXED_MT > MT_DEFAULT ? 10 : 0));

class BH1750Simple {
  public:
    explicit BH1750Simple(uint8_t addr) : _addr(addr) {}

    // 匯流排逾時保護: I2C 操作 >= 50 ms 算一次慢操作; 連續 3 次才暫停這顆感測器 2 秒。
    unsigned long slowOps = 0, blockEvents = 0, readFails = 0;
    bool blocked() { return (long)(_skipUntil - millis()) > 0; }
    void noteDuration(unsigned long t0, const char *what) {
      unsigned long dt = millis() - t0;
      if (dt < 50) { _slowRun = 0; return; }
      slowOps++;
      _slowRun++;
      Monitor.print("[photo][warn] I2C 0x"); Monitor.print(String(_addr, HEX));
      Monitor.print(" "); Monitor.print(what); Monitor.print(" took "); Monitor.print(dt); Monitor.println(" ms");
      if (_slowRun >= 3) {
        _slowRun = 0;
        blockEvents++;
        _skipUntil = millis() + 2000UL;
        Monitor.print("[photo][warn] I2C 0x"); Monitor.print(String(_addr, HEX));
        Monitor.println(": 3 slow operations in a row -> skipping this sensor for 2 s");
      }
    }

    bool cmd(uint8_t c) {
      if (blocked()) return false;
      unsigned long t0 = millis();
      Wire.beginTransmission(_addr);
      Wire.write(c);
      bool ok = Wire.endTransmission() == 0;
      noteDuration(t0, "write");
      return ok;
    }
    bool powerOn() { return cmd(0x01); }

    bool configure() {
      bool ok = cmd(0x40 | (FIXED_MT >> 5));
      ok = cmd(0x60 | (FIXED_MT & 0x1F)) && ok;
      ok = cmd(FIXED_H2 ? 0x11 : 0x10) && ok;
      return ok;
    }

    // 原始 16-bit 計數(0~65535); 失敗回傳 -1
    float readRaw() {
      if (blocked()) { readFails++; return -1.0f; }
      unsigned long t0 = millis();
      int got = Wire.requestFrom((int)_addr, 2);
      noteDuration(t0, "read");
      if (got != 2) { readFails++; return -1.0f; }
      unsigned long start = millis();
      while (Wire.available() < 2) {
        if (millis() - start > I2C_READ_TIMEOUT_MS) { readFails++; return -1.0f; }
      }
      uint16_t raw = (uint16_t)Wire.read() << 8;
      raw |= Wire.read();
      return (float)raw;
    }

  private:
    uint8_t _addr;
    unsigned long _skipUntil = 0;
    uint8_t _slowRun = 0;
};

struct Channel {
  BH1750Simple dev;
  const char  *name;
  bool         inited;

  // 重送 Power On + 量測模式(成員函式: 避開 Arduino 自動原型排在 Channel 定義之前的問題)
  bool reconfigure() {
    bool ok = dev.powerOn();
    ok = dev.configure() && ok;
    return ok;
  }
};

const uint8_t LED_PIN     = 3;
const uint8_t SAMPLE_ADDR = 0x5C;
const uint8_t REF_ADDR    = 0x23;

Channel chS = { BH1750Simple(SAMPLE_ADDR), "sample",    false };
Channel chR = { BH1750Simple(REF_ADDR),    "reference", false };

bool ledIsOn = false;
unsigned long ledOffMs = 0;
void ledSet(bool on) {
  if (ledIsOn && !on) ledOffMs = millis();
  ledIsOn = on;
  digitalWrite(LED_PIN, on ? HIGH : LOW);
}

unsigned long settleUntilMs = 0;
void markSettle() { settleUntilMs = millis() + 2UL * SAMPLE_PERIOD_MS; }

// ===========================================================================
// 二、量測參數與狀態
// ===========================================================================
const uint8_t  N_SAMPLES      = 16;
const uint8_t  N_DARK_SAMPLES = 4;
const uint16_t LED_WARMUP_MS  = 60;
const uint8_t  WARMUP_DISCARD = 2;     // Python 端計算時丟掉亮燈前 2 筆; MCU 的有效性檢查也一樣
const int      MIN_VALID_LIT  = 8;     // 亮燈(丟掉前 2 筆後)至少要有幾筆成功讀值
const uint8_t  MAX_RETRIES    = 1;

unsigned long measureIntervalMs = 30000UL;
const unsigned long MIN_MEASURE_INTERVAL_MS = 5000UL;
const unsigned long MAX_MEASURE_INTERVAL_MS = 86400000UL;

uint8_t refMode = 0;                    // 0 = 雙光路(reference 也要有效), 1 = 單光路(只看 sample)

unsigned long lastMeasMillis = 0;       // 上一次量測完成
unsigned long lastMeasStartMs = 0;      // 上一次量測開始(間隔以開始到開始計)
unsigned long odMeasSeq = 0;
String lastRawPayload = "";             // 最近一次完成量測的 final raw(get_last_raw 用)

bool devModeOn = false;

enum OdState : uint8_t { OD_IDLE = 0, OD_DARK = 1, OD_WARMUP = 2, OD_LIT = 3 };
OdState odState = OD_IDLE;
unsigned long odNextStepMs = 0;
unsigned long odAttemptStartMs = 0;
int      odSampleIdx = 0;
uint8_t  odAttempt = 0;

float odDarkS[8], odDarkR[8];
float odLitS[32], odLitR[32];

enum ReinitStep : uint8_t { RI_IDLE = 0, RI_POWER = 1, RI_CONF = 2, RI_SETTLE = 3 };
ReinitStep riStep = RI_IDLE;
unsigned long riNextMs = 0;
unsigned long riLastAutoMs = 0;
bool riOk = false;
bool riSampleNeeded = false, riRefNeeded = false;
Channel *riTarget = nullptr;
unsigned long reinitCountS = 0, reinitCountR = 0, busResetCount = 0;
bool lastAttemptStuck = false;   // 剛結束的嘗試有讀值卡住 → 重試前直接重置 I2C
bool busResetPending = false;

// 成功讀值(>= 0)的筆數
int countValid(const float *a, int n) {
  int c = 0;
  for (int i = 0; i < n; i++) if (a[i] >= 0) c++;
  return c;
}

// 卡住: 成功讀值全部相同, 而且是 0 或 >= 50 count(弱光時少數幾個 count 重複是正常的), 不是飽和
bool isStuck(const float *a, int n) {
  float v = -2.0f;
  int m = 0;
  for (int i = 0; i < n; i++) {
    if (a[i] < 0) continue;
    if (m == 0) v = a[i];
    else if (a[i] != v) return false;
    m++;
  }
  if (m < MIN_VALID_LIT || v >= RAW_SATURATED - 0.5f) return false;
  return v == 0.0f || v >= 50.0f;
}

// ===========================================================================
// 三、重新初始化
// ===========================================================================
String fullI2CReset(const char *why) {
  busResetCount++;
  Monitor.print("[photo][warn] I2C controller reset ("); Monitor.print(why); Monitor.println(")");
  Wire.end();
  delay(2);
  Wire.begin();
  bool okS = chS.reconfigure();
  bool okR = chR.reconfigure();
  chS.inited = okS;
  chR.inited = okR;
  reinitCountS++; reinitCountR++;
  markSettle();
  return String("S:") + (okS ? "ok" : "fail") + "|R:" + (okR ? "ok" : "fail");
}

void reinitTick() {
  unsigned long now = millis();
  if (riStep == RI_IDLE) {
    if (odState != OD_IDLE) return;
    if ((!chS.inited || !chR.inited) && now - riLastAutoMs >= 10000UL) {
      riLastAutoMs = now;
      if (!chS.inited) riSampleNeeded = true;
      if (!chR.inited) riRefNeeded = true;
    }
    if (riSampleNeeded)   { riTarget = &chS; riSampleNeeded = false; }
    else if (riRefNeeded) { riTarget = &chR; riRefNeeded = false; }
    else return;
    riStep = RI_POWER;
    riNextMs = now;
  }
  if ((long)(now - riNextMs) < 0) return;

  if (riStep == RI_POWER) {
    if (riTarget == &chS) reinitCountS++; else reinitCountR++;
    riOk = riTarget->dev.powerOn();
    riStep = RI_CONF;
    riNextMs = now + 10;
  } else if (riStep == RI_CONF) {
    riOk = riTarget->dev.configure() && riOk;
    riStep = RI_SETTLE;
    riNextMs = now + 2UL * SAMPLE_PERIOD_MS;
  } else if (riStep == RI_SETTLE) {
    bool was = riTarget->inited;
    riTarget->inited = riOk;
    if (riOk || was) {
      Monitor.print(riOk ? "[photo] " : "[photo][warn] ");
      Monitor.print(riTarget->name);
      Monitor.println(riOk ? " sensor (re)initialized OK" : " sensor reinit FAILED");
    }
    riStep = RI_IDLE;
    riTarget = nullptr;
    markSettle();
  }
}

// ===========================================================================
// 四、量測狀態機(只取樣, 不計算)
// ===========================================================================
bool odStartMeasurement() {
  if (devModeOn || odState != OD_IDLE) return false;
  odAttempt = 0;
  odSampleIdx = 0;
  odState = OD_DARK;
  ledSet(false);
  lastMeasStartMs = millis();
  if (busResetPending) {
    busResetPending = false;
    fullI2CReset("sensor stuck again after reinit");
  } else {
    if (chS.inited) chS.reconfigure();
    if (chR.inited) chR.reconfigure();
    markSettle();
  }
  unsigned long t = millis();
  if ((long)(settleUntilMs - t) > 0) t = settleUntilMs;
  unsigned long darkOk = ledOffMs + 2UL * SAMPLE_PERIOD_MS;
  if ((long)(darkOk - t) > 0) t = darkOk;
  odNextStepMs = t;
  return true;
}

String joinVals(const float *a, int n) {
  String s;
  for (int i = 0; i < n; i++) {
    if (i) s += "|";
    s += String((long)lroundf(a[i]));
  }
  return s;
}

// 一次嘗試結束: 檢查硬體層有效性、推 raw、決定要不要重試。回傳 true = 這次量測結束。
bool odFinishAttempt() {
  const float *s = odLitS + WARMUP_DISCARD;
  const float *r = odLitR + WARMUP_DISCARD;
  int n = N_SAMPLES - WARMUP_DISCARD;
  bool useRef = (refMode == 0);

  bool stS = isStuck(s, n), stR = isStuck(r, n);
  bool enoughS = countValid(s, n) >= MIN_VALID_LIT;
  bool enoughR = countValid(r, n) >= MIN_VALID_LIT;
  bool hwOk = enoughS && !stS && (!useRef || (enoughR && !stR));
  bool final = hwOk || odAttempt >= MAX_RETRIES;

  // 硬體問題就地處理: 讀取失敗多 → 重新初始化; 卡住 → 重新初始化, 連續卡住 → 重置 I2C
  if (!enoughS) riSampleNeeded = true;
  if (!enoughR && useRef) riRefNeeded = true;
  bool sS = stS, sR = useRef && stR;
  if (sS || sR) {
    Monitor.print("[photo][warn] sensor stuck (readings frozen):");
    if (sS) Monitor.print(" sample");
    if (sR) Monitor.print(" reference");
    if (final) {
      busResetPending = true;
      Monitor.println(" -> still frozen after I2C reset, reset again before next measurement");
    } else {
      Monitor.println(" -> I2C controller reset, retry now");
    }
  }
  lastAttemptStuck = sS || sR;

  String p = String("seq=") + (odMeasSeq + 1) +
             ",att=" + odAttempt +
             ",final=" + (final ? 1 : 0) +
             ",hw_ok=" + (hwOk ? 1 : 0) +
             ",stuck=" + (stS && stR ? "SR" : stS ? "S" : stR ? "R" : "-") +
             ",t0=" + odAttemptStartMs +
             ",per=" + SAMPLE_PERIOD_MS +
             ",mt=" + FIXED_MT + ",h2=" + (FIXED_H2 ? 1 : 0) +
             ",lpc=" + String(LUX_PER_COUNT, 6) +
             ",ref_mode=" + refMode +
             ",ds=" + joinVals(odDarkS, N_DARK_SAMPLES) +
             ",dr=" + joinVals(odDarkR, N_DARK_SAMPLES) +
             ",ls=" + joinVals(odLitS, N_SAMPLES) +
             ",lr=" + joinVals(odLitR, N_SAMPLES);
  Bridge.notify("on_od_raw", p);

  if (final) {
    lastRawPayload = p;
    lastMeasMillis = millis();
    odMeasSeq++;
    Monitor.print("[photo] seq="); Monitor.print(odMeasSeq);
    Monitor.print(" attempts="); Monitor.print(odAttempt + 1);
    Monitor.print(" hw_ok="); Monitor.println(hwOk ? "yes" : "no");
  }
  return final;
}

void odTick() {
  if (devModeOn) return;
  unsigned long now = millis();

  switch (odState) {
    case OD_IDLE:
      if (now - lastMeasStartMs >= measureIntervalMs && riStep == RI_IDLE) odStartMeasurement();
      break;

    case OD_DARK:
      if ((long)(now - odNextStepMs) < 0) break;
      if (odSampleIdx == 0) odAttemptStartMs = now;
      odDarkS[odSampleIdx] = chS.dev.readRaw();
      odDarkR[odSampleIdx] = chR.dev.readRaw();
      odSampleIdx++;
      odNextStepMs = now + SAMPLE_PERIOD_MS;
      if (odSampleIdx >= N_DARK_SAMPLES) {
        ledSet(true);
        odState = OD_WARMUP;
        odNextStepMs = now + LED_WARMUP_MS;
      }
      break;

    case OD_WARMUP:
      if ((long)(now - odNextStepMs) < 0) break;
      odSampleIdx = 0;
      odState = OD_LIT;
      odNextStepMs = now;
      break;

    case OD_LIT:
      if ((long)(now - odNextStepMs) < 0) break;
      odLitS[odSampleIdx] = chS.dev.readRaw();
      odLitR[odSampleIdx] = chR.dev.readRaw();
      odSampleIdx++;
      odNextStepMs = now + SAMPLE_PERIOD_MS;
      if (odSampleIdx >= N_SAMPLES) {
        ledSet(false);
        if (odFinishAttempt()) {
          odState = OD_IDLE;
        } else {
          odAttempt++;
          odSampleIdx = 0;
          odState = OD_DARK;
          // 重試前: 讀值卡住 → 直接重置 I2C 控制器 + 兩顆重新設定(幾 ms, 同一次量測內就恢復);
          //         只是讀取失敗 → 重送量測模式(完整重新初始化由 reinitTick 在量測結束後處理)
          if (lastAttemptStuck) {
            fullI2CReset("sensor stuck, before retry");
          } else {
            if (chS.inited) chS.reconfigure();
            if (chR.inited) chR.reconfigure();
            markSettle();
          }
          unsigned long t = now + 2UL * SAMPLE_PERIOD_MS;
          if ((long)(settleUntilMs - t) > 0) t = settleUntilMs;
          odNextStepMs = t;
        }
      }
      break;
  }
}

// ===========================================================================
// 五、Bridge 介面
// ===========================================================================
String trigger_measurement(String arg) {
  return odStartMeasurement() ? "queued" : "busy";
}

String get_last_raw(String arg) {
  return lastRawPayload + ",age_ms=" + String(millis() - lastMeasMillis) + ",busy=" + (odState != OD_IDLE ? 1 : 0);
}

String get_config(String arg) {
  return String("interval_s=") + String(measureIntervalMs / 1000.0f, 2) +
         ",ref_mode=" + (int)refMode +
         ",mt=" + FIXED_MT + ",h2=" + (FIXED_H2 ? 1 : 0) +
         ",period_ms=" + SAMPLE_PERIOD_MS +
         ",lpc=" + String(LUX_PER_COUNT, 6);
}

String set_config(String arg) {
  float v;
  float interval = -1; int rm = -1;
  if (kvGet(arg, "interval_s", v)) {
    if (v < MIN_MEASURE_INTERVAL_MS / 1000.0f || v > MAX_MEASURE_INTERVAL_MS / 1000.0f) return "rejected:interval 5-86400 s";
    interval = v;
  }
  if (kvGet(arg, "ref_mode", v)) {
    if (v != 0 && v != 1) return "rejected:ref_mode 0|1";
    rm = (int)v;
  }
  if (interval > 0) measureIntervalMs = (unsigned long)(interval * 1000.0f);
  if (rm >= 0) refMode = (uint8_t)rm;
  Monitor.print("[photo][cfg] "); Monitor.println(get_config(""));
  return get_config("");
}

String set_dev_mode(String arg) {
  bool on = (arg.toInt() != 0);
  devModeOn = on;
  if (on) {
    odState = OD_IDLE;
    if (chS.inited) chS.reconfigure();
    if (chR.inited) chR.reconfigure();
    ledSet(true);
  } else {
    ledSet(false);
    lastMeasMillis = millis();
    lastMeasStartMs = millis();
  }
  Monitor.println(on ? "[photo][align] LED forced ON, auto measurement paused"
                     : "[photo][align] LED off, auto measurement resumed");
  return on ? "1" : "0";
}

String get_dev_readings(String arg) {
  if (!devModeOn) return "0,-1,-1,-1,-1";
  float rs = chS.dev.readRaw();
  float rr = chR.dev.readRaw();
  float ls = rs < 0 ? -1.0f : rs * LUX_PER_COUNT;
  float lr = rr < 0 ? -1.0f : rr * LUX_PER_COUNT;
  return String("1,") + String(rs, 0) + "," + String(rr, 0) + "," + String(ls, 3) + "," + String(lr, 3);
}

String reinit_sensors(String arg) {
  if (odState != OD_IDLE) return "busy";
  String r = fullI2CReset("manual");
  lastAttemptStuck = false;
  return r;
}

// ---- 診斷 ----
unsigned long loopMaxUs = 0, loopMaxUsLastSec = 0, lastDiagMs = 0;
const char * volatile bootStage = "bridge";
String i2cStatusS = "?", i2cStatusR = "?";

String get_diag(String arg) {
  return String(loopMaxUsLastSec) + "," +
         String((int)odState) + "," +
         String((int)riStep) + "," +
         String(millis()) + "," + String((const char *)bootStage) + "," +
         "i2c=S:" + i2cStatusS + "|R:" + i2cStatusR + "," +
         "rc=S:" + reinitCountS + "|R:" + reinitCountR + "|B:" + busResetCount + "," +
         "io=S:" + chS.dev.slowOps + "/" + chS.dev.blockEvents + "/" + chS.dev.readFails +
         "|R:" + chR.dev.slowOps + "/" + chR.dev.blockEvents + "/" + chR.dev.readFails + "," + FW_VERSION;
}

void diagTick(unsigned long now) {
  if (now - lastDiagMs < 1000) return;
  lastDiagMs = now;
  loopMaxUsLastSec = loopMaxUs;
  loopMaxUs = 0;
}

// ===========================================================================
// 六、setup / loop
// ===========================================================================
String i2cProbe(uint8_t addr, unsigned long &dtMs) {
  unsigned long t0 = millis();
  Wire.beginTransmission(addr);
  uint8_t err = Wire.endTransmission();
  dtMs = millis() - t0;
  if (err == 0) return "ok";
  if (dtMs >= 50) return "timeout";
  if (err == 2 || err == 3) return "nak";
  return String("err") + err;
}

bool bootBannerPrinted = false;

void setup() {
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  pinMode(LED_BUILTIN, OUTPUT);
  for (int i = 0; i < 2; i++) { digitalWrite(LED_BUILTIN, LOW); delay(80); digitalWrite(LED_BUILTIN, HIGH); delay(80); }
  digitalWrite(LED_BUILTIN, LOW);

  bool bridgeOk = Bridge.begin();   // 不要呼叫 Serial.begin()
  Monitor.begin();
  digitalWrite(LED_BUILTIN, HIGH);
  delay(500);

  Monitor.println();
  Monitor.print("[boot] Inline photometer " FW_VERSION " (raw acquisition only), Bridge.begin=");
  Monitor.println(bridgeOk ? "OK" : "FAILED");

  Bridge.provide("get_diag", get_diag);
  Monitor.println("[boot] step 1/4: get_diag registered");

  bootStage = "i2c_scan";
  Monitor.println("[boot] step 2/4: I2C probe 0x5C / 0x23");
  Wire.begin();
  unsigned long dtS = 0, dtR = 0;
  i2cStatusS = i2cProbe(SAMPLE_ADDR, dtS);
  Monitor.print("[boot]   sample    0x5C: "); Monitor.print(i2cStatusS); Monitor.print(" ("); Monitor.print(dtS); Monitor.println(" ms)");
  i2cStatusR = i2cProbe(REF_ADDR, dtR);
  Monitor.print("[boot]   reference 0x23: "); Monitor.print(i2cStatusR); Monitor.print(" ("); Monitor.print(dtR); Monitor.println(" ms)");

  bootStage = "sensor_init";
  Monitor.print("[boot] step 3/4: BH1750 init (fixed MTreg ");
  Monitor.print(FIXED_MT); Monitor.print(FIXED_H2 ? ", H-res mode 2" : ", H-res mode 1");
  Monitor.print(", read every "); Monitor.print(SAMPLE_PERIOD_MS); Monitor.println(" ms)");
  bool busDead = (i2cStatusS == "timeout") || (i2cStatusR == "timeout");
  bool okS = false, okR = false;
  if (!busDead) {
    if (i2cStatusS == "ok") okS = chS.dev.powerOn();
    if (i2cStatusR == "ok") okR = chR.dev.powerOn();
    delay(10);
    if (okS) okS = chS.dev.configure();
    if (okR) okR = chR.dev.configure();
    delay(2 * SAMPLE_PERIOD_MS);
  }
  Monitor.print("[boot] sample    (0x5C): "); Monitor.println(okS ? "OK" : "FAILED - see probe result above");
  Monitor.print("[boot] reference (0x23): "); Monitor.println(okR ? "OK" : "FAILED - see probe result above (ignore if single-path)");
  chS.inited = okS;
  chR.inited = okR;
  riLastAutoMs = millis();

  bootStage = "register";
  Bridge.provide_safe("trigger_measurement", trigger_measurement);
  Bridge.provide_safe("get_last_raw", get_last_raw);
  Bridge.provide_safe("get_config", get_config);
  Bridge.provide_safe("set_config", set_config);
  Bridge.provide_safe("set_dev_mode", set_dev_mode);
  Bridge.provide_safe("get_dev_readings", get_dev_readings);
  Bridge.provide_safe("reinit_sensors", reinit_sensors);
  Monitor.println("[boot] step 4/4: Bridge functions registered");
  bootStage = "ready";

  lastMeasMillis = millis();
  lastMeasStartMs = millis();
  lastDiagMs = millis();
  Monitor.print("[boot] ready. first auto measurement in ");
  Monitor.print(measureIntervalMs / 1000);
  Monitor.println(" s (interval is set by the Python side).");
}

void loop() {
  if (!bootBannerPrinted) {
    Monitor.println("[boot] entering loop()");
    bootBannerPrinted = true;
  }
  unsigned long t0 = micros();
  unsigned long now = millis();

  odTick();
  reinitTick();

  unsigned long us = micros() - t0;
  if (us > loopMaxUs) loopMaxUs = us;
  diagTick(now);
}
