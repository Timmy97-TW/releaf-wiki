# -*- coding: utf-8 -*-
"""
Inline Photometer — 演算法(v1.2.0 起全部在 Linux 端計算)
=========================================================
main.py(即時)與 tools/replay.py(離線重跑)共用這一份, 兩邊的結果保證一致。
只用 Python 標準函式庫。

一次「嘗試」的原始讀值(MCU on_od_raw):
    ds / dr : 暗電流 4 筆(sample / reference)
    ls / lr : 亮燈 16 筆; 前 WARMUP_DISCARD 筆是 LED 穩定期, 一律丟掉
    讀取失敗記為 -1, 一律先排除(不當成讀值)

估計演算法(單次量測內, 亮燈 14 筆 → 一個值):
    mad       median ± 3·MAD 閘門內平均
    qn        Rousseeuw–Croux Qn 尺度的閘門
    biweight  Tukey biweight (c = 4.685)
    upper     單邊: 只剔除過低值(氣泡遮光), 取中位數以上平均
    mean      直接平均(對照組)
    median    中位數
    p75, p90  第 75 / 90 百分位(上包絡)
尺度下限 1 count + 0.2%(整數計數、讀值大量相同時 MAD/Qn 會變 0)。

氣泡比例(與演算法無關, 只看 sample 通道):
    低於「上包絡 P90 × (1 − BUBBLE_DROP)」的亮燈讀值比例。超過 REJECT_LIMIT_PCT(50%)時,
    這次量測對「所有」演算法都判為無效 —— 讀值多半是氣泡時, 以中位數為基礎的方法會把氣泡當成真值,
    而且自己的拒收率看起來是 0(安靜地錯), 所以不能只看各演算法自己的拒收率。
"""

import math
from collections import OrderedDict

MAD_K = 3.0
WARMUP_DISCARD = 2
MIN_VALID_LIT = 8
REJECT_LIMIT_PCT = 50.0
RAW_SAT = 65535.0
LOW_SIGNAL_COUNTS = 300.0
BUBBLE_DROP = 0.05          # 比上包絡低 5% 以上才算氣泡(另有 3 × 尺度下限的最小距離)


def median(a):
    s = sorted(a)
    n = len(s)
    return s[n // 2] if n % 2 else 0.5 * (s[n // 2 - 1] + s[n // 2])


def scale_floor(med):
    return 1.0 + 0.002 * abs(med)


def mad_scale(a, med):
    return max(median([abs(x - med) for x in a]) * 1.4826, scale_floor(med))


def qn_scale(a):
    d = sorted(abs(a[i] - a[j]) for i in range(len(a)) for j in range(i + 1, len(a)))
    if not d:
        return 1e-6
    h = len(a) // 2 + 1
    k = min(max(h * (h - 1) // 2, 1), len(d))
    return max(2.2219 * d[k - 1], 1e-6)


def est_mad(a):
    med = median(a)
    sc = mad_scale(a, med)
    kept = [x for x in a if abs(x - med) <= MAD_K * sc]
    return (sum(kept) / len(kept) if kept else med), 100.0 * (len(a) - len(kept)) / len(a)


def est_qn(a):
    med = median(a)
    sc = max(qn_scale(a), scale_floor(med))
    kept = [x for x in a if abs(x - med) <= MAD_K * sc]
    return (sum(kept) / len(kept) if kept else med), 100.0 * (len(a) - len(kept)) / len(a)


def est_biweight(a):
    med = median(a)
    sc = mad_scale(a, med)
    c = 4.685
    T = med
    for _ in range(8):
        sw = swx = 0.0
        for x in a:
            u = (x - T) / (c * sc)
            if abs(u) < 1.0:
                w = (1 - u * u) ** 2
                sw += w
                swx += w * x
        if sw <= 0:
            break
        Tn = swx / sw
        if abs(Tn - T) < 1e-4 * (abs(T) + 1e-3):
            T = Tn
            break
        T = Tn
    rej = sum(1 for x in a if abs((x - T) / (c * sc)) >= 1.0)
    return T, 100.0 * rej / len(a)


def est_upper(a):
    med = median(a)
    sc = mad_scale(a, med)
    rej = sum(1 for x in a if x < med - MAD_K * sc)
    kept = [x for x in a if x >= med]
    return (sum(kept) / len(kept) if kept else med), 100.0 * rej / len(a)


def est_mean(a):
    return sum(a) / len(a), 0.0


def est_median(a):
    return median(a), 0.0


def _percentile(a, p):
    s = sorted(a)
    k = (len(s) - 1) * p / 100.0
    lo, hi = math.floor(k), math.ceil(k)
    return s[lo] if lo == hi else s[lo] + (s[hi] - s[lo]) * (k - lo)


def est_pct(p):
    def f(a):
        v = _percentile(a, p)
        sc = mad_scale(a, median(a))
        rej = sum(1 for x in a if x < v - MAD_K * sc)    # 明顯低於上包絡的比例(品質指標)
        return v, 100.0 * rej / len(a)
    return f


ESTIMATORS = OrderedDict([
    ("mad", est_mad), ("qn", est_qn), ("biweight", est_biweight), ("upper", est_upper),
    ("mean", est_mean), ("median", est_median), ("p75", est_pct(75)), ("p90", est_pct(90)),
])
ALG_NAMES = list(ESTIMATORS)
ALG_LABELS = {
    "mad": "MAD", "qn": "Qn", "biweight": "Tukey biweight", "upper": "upper (one-sided)",
    "mean": "mean", "median": "median", "p75": "P75", "p90": "P90",
}


def valid(a):
    return [x for x in a if x >= 0]


def bubble_pct(a):
    """與演算法無關的氣泡比例: 明顯低於上包絡(P90)的讀值佔幾 %。"""
    if not a:
        return 100.0
    top = _percentile(a, 90)
    thr = top - max(BUBBLE_DROP * top, 3.0 * scale_floor(top))
    return 100.0 * sum(1 for x in a if x < thr) / len(a)


def attempt_result(att, alg, single):
    """一次嘗試 + 一種演算法 → dict(S, R 為扣暗電流後的等效 lux)"""
    est = ESTIMATORS[alg]
    s = valid(att["ls"][WARMUP_DISCARD:])
    r = valid(att["lr"][WARMUP_DISCARD:])
    litS, rejS = est(s) if s else (0.0, 100.0)
    litR, rejR = est(r) if r else (0.0, 100.0)
    ds, dr = valid(att["ds"]), valid(att["dr"])
    dS = median(ds) if ds else 0.0
    dR = median(dr) if dr else 0.0
    lpc = att["lpc"]
    satS = any(x >= RAW_SAT - 0.5 for x in s)
    satR = any(x >= RAW_SAT - 0.5 for x in r)
    enoughS = len(s) >= MIN_VALID_LIT
    enoughR = len(r) >= MIN_VALID_LIT
    rej = rejS if single else max(rejS, rejR)
    netS, netR = litS - dS, litR - dR
    hw_ok = att.get("hw_ok", enoughS and (single or enoughR))
    bub = bubble_pct(s)
    ok = hw_ok and rej <= REJECT_LIMIT_PCT and bub <= REJECT_LIMIT_PCT and not satS and (single or not satR) and enoughS and (single or enoughR)
    return {
        "S": max(netS * lpc, 0.0), "R": max(netR * lpc, 0.0),
        "counts_s": litS, "counts_r": litR, "rej": rej, "bubble": bub, "ok": ok,
        "sat_s": satS, "sat_r": satR, "enough_s": enoughS, "enough_r": enoughR,
        "low_s": netS < LOW_SIGNAL_COUNTS, "low_r": netR < LOW_SIGNAL_COUNTS,
        "n_valid_s": len(s), "n_valid_r": len(r),
    }


def measurement_result(attempts, alg, single):
    """同一次量測的多次嘗試: 先選有效的, 再比拒收率(與韌體 v1.1.3 相同的規則)。"""
    best = None
    for att in attempts:
        res = attempt_result(att, alg, single)
        if best is None or (res["ok"] and not best["ok"]) or (res["ok"] == best["ok"] and res["rej"] < best["rej"]):
            best = res
    return best


def od_values(res, blank_alg, plf):
    """dual / single OD。blank_alg = 這個演算法自己的 blank {"s","r","ratio"}(None = 尚未校正)。"""
    if not blank_alg or plf <= 0:
        return None, None
    S, R = res["S"], res["R"]
    bS, bR = blank_alg.get("s") or 0.0, blank_alg.get("r") or 0.0
    bRatio = blank_alg.get("ratio") or (bS / bR if bS > 0 and bR > 0 else 0.0)   # 手動輸入可能只有比值
    dual = single = None
    if S > 0 and R > 0 and bRatio > 0:
        dual = math.log10(bRatio / (S / R)) * plf
    if S > 0 and bS > 0:
        single = math.log10(bS / S) * plf
    return dual, single


def hampel(series, window=7, k=3.0, causal=False):
    """Hampel 濾波: 視窗內中位數 ± k·MAD 以外的點以中位數取代。causal=True 只用過去的點(即時用)。"""
    out = list(series)
    half = window // 2
    for i, v in enumerate(series):
        if v is None:
            continue
        lo, hi = (max(0, i - window + 1), i + 1) if causal else (max(0, i - half), i + half + 1)
        win = [x for x in series[lo:hi] if x is not None]
        if len(win) < 3:
            continue
        med = median(win)
        mad = 1.4826 * median([abs(x - med) for x in win])
        if mad > 0 and abs(v - med) > k * mad:
            out[i] = med
    return out
