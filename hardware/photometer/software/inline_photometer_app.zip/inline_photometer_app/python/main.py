# -*- coding: utf-8 -*-
# ============================================================================
# Inline Photometer — Linux/MPU 端 main.py (Arduino UNO Q / App Lab)
# ============================================================================
# v1.2.0 (2026-10-10): 「MCU 只讀原始值, Python 算所有東西」
#   MCU 每次量測推 on_od_raw(暗電流 4 筆 + 亮燈 16 筆, 兩通道, 可能有一次重試)。這裡:
#     - 用 photometer_algos.py 對同一筆原始讀值同時計算 8 種估計演算法(mad, qn, biweight, upper,
#       mean, median, p75, p90), 每種都有自己的 blank, 各自算出 OD → 曲線圖可以同時顯示
#     - 「主要演算法」(網頁選的)決定顯示的 OD600、有效性與 CSV 的 od600 欄; 其他演算法也都寫進 CSV
#     - blank、光程長係數、光路模式(光纖 / 分光鏡 / 單光路)全部在這裡; MCU 只收量測間隔與 ref_mode
#     - 與演算法無關的氣泡比例 > 50% → 所有演算法都判無效; 氣泡比例或主要演算法拒收率 > 50% 時立刻請 MCU 再量一次
#     - 換演算法 / 光程長係數 / blank 後, 目前顯示的值立刻用最後一筆原始讀值重算, 不必等下一次量測
#   tools/replay.py 與這裡共用 photometer_algos.py, 離線重跑的結果與即時計算一致。
#
# 網頁 → 後端(ui.on_message):
#   get_state, measure_now, calibrate_blank, set_config{interval_s,plf,od_alg,optical_mode,split_s,split_r},
#   set_blank_manual{ratio,s,r}, clear_blank, set_dev_mode{on}, get_dev_readings, reinit_sensors,
#   start_record{duration_sec,label}, stop_record, add_note{text}, list_recordings
# 後端 → 網頁(ui.send_message):
#   od_update, blank_info, config, calib_state, mcu_link, dev_status, dev_readings, action_result,
#   blank_result, history, history_point, record_status, recordings_list, record_saved, record_error
# ============================================================================

import csv
import json
import math
import os
import queue
import sys
import threading
import time
import traceback
from collections import deque
from datetime import datetime

from arduino.app_utils import *
from arduino.app_bricks.web_ui import WebUI

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import photometer_algos as PA  # noqa: E402

BACKEND_VERSION = "photometer-py v1.2.0"
EXPECTED_FW = "photometer-fw v1.2.0"

ui = WebUI()

# ============================= 設定檔 =============================
_DIR = os.path.dirname(os.path.abspath(__file__))
_DEFAULT_CONST = {
    "config_version": "embedded-fallback",
    "poll_interval_sec": 5.0,
    "dev_mode_poll_timeout_sec": 30.0,
    "default_measure_interval_sec": 30.0,
    "default_path_length_factor": 5.0,
    "default_optical_mode": "fiber",
    "default_splitter_ratio": [9, 1],
    "default_algorithm": "upper",
    "splitter_ratio_tolerance": 2.0,
    "ref_rel_warn_band": [0.85, 1.15],
    "low_signal_counts": 300,
    "bubble_retry": True,
    "bubble_drop_pct": 5.0,
    "history_max_points": 5000,
    "recordings_dir": "recordings",
}


def _load_constants():
    for path in (os.path.join(_DIR, "constants.json"), os.path.join(os.getcwd(), "constants.json"),
                 "/app/python/constants.json"):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            merged = dict(_DEFAULT_CONST)
            merged.update({k: v for k, v in data.items() if not k.startswith("_")})
            print(f"[constants] 已讀取 {path}")
            return merged
        except FileNotFoundError:
            continue
        except (OSError, json.JSONDecodeError) as e:
            print(f"[constants] WARNING: {path} 讀取失敗({e})")
    print("[constants] WARNING: 找不到 constants.json, 使用內嵌預設值")
    return dict(_DEFAULT_CONST)


CONST = _load_constants()
POLL_INTERVAL_SEC = float(CONST["poll_interval_sec"])
DEV_TIMEOUT_SEC = float(CONST["dev_mode_poll_timeout_sec"])
REF_REL_BAND = [float(x) for x in CONST["ref_rel_warn_band"]]
SPLIT_TOL = max(1.01, float(CONST["splitter_ratio_tolerance"]))
PA.LOW_SIGNAL_COUNTS = float(CONST["low_signal_counts"])
PA.BUBBLE_DROP = float(CONST["bubble_drop_pct"]) / 100.0
BUBBLE_RETRY = bool(CONST["bubble_retry"])
FULL_SCALE = 65535.0
ALGS = PA.ALG_NAMES
OPTICAL_MODES = ("fiber", "splitter", "single")
DEFAULT_ALG = CONST["default_algorithm"] if CONST["default_algorithm"] in ALGS else "upper"
OLD_ALG_INDEX = ["mad", "qn", "biweight", "upper"]           # v1.1.x 存檔用的是編號

RECORDINGS_DIR = CONST["recordings_dir"]
if not os.path.isabs(RECORDINGS_DIR):
    RECORDINGS_DIR = os.path.join(_DIR, RECORDINGS_DIR)
os.makedirs(RECORDINGS_DIR, exist_ok=True)
CALIB_PATH = os.path.join(_DIR, "calibration_state.json")
RECORD_STATE_PATH = os.path.join(_DIR, "recording_state.json")

REF_FLAGS = ("sat_r", "low_r", "i2c_r", "stuck_r", "ref_drift")


# ============================= 共用小工具 =============================
def parse_kv(s):
    out = {}
    for tok in str(s or "").split(","):
        if "=" in tok:
            k, v = tok.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def _f(x, default=0.0):
    try:
        v = float(x)
        return v if math.isfinite(v) else default
    except (TypeError, ValueError):
        return default


def alg_name(v):
    if v in ALGS:
        return v
    try:
        i = int(float(v))
        return OLD_ALG_INDEX[i] if 0 <= i < len(OLD_ALG_INDEX) else DEFAULT_ALG
    except (TypeError, ValueError):
        return DEFAULT_ALG


def bridge(name, arg=""):
    """Bridge.call 包一層: 成功回傳字串, 失敗丟出例外並更新 mcu_link。"""
    try:
        r = Bridge.call(name, arg)
    except Exception as e:
        msg = f"{name}: {type(e).__name__}: {e}"
        if "not available" in str(e):
            fw = mcu_link.get("fw")
            msg += (f" —— MCU 上的 sketch 沒有這個函式, 目前跑的是「{fw}」而不是 {EXPECTED_FW}。"
                    "請重新上傳 photometer 的 sketch(App Lab log 應出現 [boot] Inline photometer)。"
                    if fw and fw != EXPECTED_FW else
                    "" if fw else
                    " —— MCU 上連 get_diag 都沒有註冊: sketch 沒有在 MCU 上執行(沒上傳成功 / 當掉),"
                    " 或卡在 setup() 裡。請看 App Lab log 的編譯/上傳訊息與 [boot] 行, 以及板上 LED。")
        _set_mcu_link(False, msg)
        raise
    return str(r if r is not None else "").strip()


# 網頁操作與「Bridge 回呼裡不能做的同步呼叫」都丟到單一工作執行緒
_work_q = queue.Queue()


def _worker():
    while True:
        fn, args = _work_q.get()
        try:
            fn(*args)
        except Exception:
            print(f"[worker] 例外:\n{traceback.format_exc()}")


def on_ui(name):
    def deco(fn):
        def handler(client, data):
            if name != "get_dev_readings":
                print(f"[ui] <- {name} {data}")
            _work_q.put((fn, (client, data or {})))
        ui.on_message(name, handler)
        return fn
    return deco


def send(name, data, client=None):
    try:
        if client is None:
            ui.send_message(name, data)
        else:
            ui.send_message(name, data, client)
    except Exception as e:
        print(f"[ui] send_message({name}) 失敗: {e}")


def action_result(client, action, ok, error=None, **extra):
    send("action_result", dict({"action": action, "ok": ok, "error": error}, **extra), client)


# ============================= MCU 連線狀態 =============================
mcu_link = {"ok": None, "error": None, "fw": None, "since": time.time(), "warn": None, "reinit": None, "io": None,
            "loop_max_ms": None}
_link_lock = threading.Lock()


def _link_snapshot():
    with _link_lock:
        return dict(mcu_link, expected_fw=EXPECTED_FW, backend=BACKEND_VERSION)


def _set_mcu_link(ok, error=None, fw=None):
    with _link_lock:
        changed = mcu_link["ok"] != ok or (fw and fw != mcu_link["fw"])
        mcu_link["ok"] = ok
        mcu_link["error"] = None if ok else error
        if fw:
            mcu_link["fw"] = fw
        if changed:
            mcu_link["since"] = time.time()
    if changed:
        snap = _link_snapshot()
        if ok:
            print(f"[mcu] Bridge 正常, fw={snap['fw']}" +
                  ("" if snap["fw"] == EXPECTED_FW else f"  !! 預期 {EXPECTED_FW}: MCU 上跑的不是這一版 sketch"))
        else:
            print(f"[mcu] !! MCU 沒有回應: {error}")
        send("mcu_link", snap)


# ============================= 狀態 =============================
_lock = threading.Lock()
cfg = {
    "interval_s": float(CONST["default_measure_interval_sec"]), "plf": float(CONST["default_path_length_factor"]),
    "od_alg": DEFAULT_ALG,
    "optical_mode": CONST["default_optical_mode"] if CONST["default_optical_mode"] in OPTICAL_MODES else "fiber",
    "split_s": float(CONST["default_splitter_ratio"][0]), "split_r": float(CONST["default_splitter_ratio"][1]),
    # 以下由 MCU get_config 讀回(唯讀)
    "ref_mode": 0, "mt": 69, "h2": 1, "period_ms": 130, "lpc": 0.416667,
}
# blank: 每種演算法各自的 {s, r, ratio}; blank_set=False 代表未校正
blank = {"blank_set": False, "per_alg": {}, "at": None}
latest = {"ts": 0.0, "meas_seq": 0, "valid": False, "blank_set": False, "flag_list": [], "algs": {},
          "od600": None, "od_dual": None, "od_single": None, "age_s": None, "busy": False}
history = deque(maxlen=int(CONST["history_max_points"]))
_last_attempts = []          # 最後一次量測的原始嘗試(換設定時重算用)
_pending_attempts = {}       # seq → 尚未收到 final 的嘗試
_last_seen_seq = None
_blank_pending = False       # 使用者按了「校正空白」: 下一次完成的量測當成 blank
_retry_for_seq = None        # 氣泡太多而要求重量的那一次 seq(每次量測最多重量一次)

dev_mode = False
_dev_last_poll = None


def ref_mode_for(optical_mode):
    return 1 if optical_mode == "single" else 0


def splitter_expected():
    if cfg["optical_mode"] != "splitter":
        return None
    s, r = _f(cfg["split_s"]), _f(cfg["split_r"])
    return s / r if s > 0 and r > 0 else None


def splitter_check(ratio):
    exp = splitter_expected()
    if exp is None or not ratio or ratio <= 0:
        return None, None
    rel = ratio / exp
    return (1.0 / SPLIT_TOL) <= rel <= SPLIT_TOL, round(rel, 3)


def blank_view(alg=None):
    """主要演算法(或指定演算法)的 blank: {blank_set, ratio, s, r}"""
    with _lock:
        b = (blank["per_alg"].get(alg or cfg["od_alg"]) or {}) if blank["blank_set"] else {}
        bs = blank["blank_set"]
    s, r = b.get("s") or 0.0, b.get("r") or 0.0
    ratio = b.get("ratio") or (s / r if s > 0 and r > 0 else 0.0)
    return {"blank_set": bs, "ratio": ratio, "s": s, "r": r}


# ============================= 計算 =============================
def compute(attempts):
    """一次量測(1~2 次嘗試)→ 8 種演算法的結果 + 主要演算法的快照。"""
    with _lock:
        c = dict(cfg)
        bl = {k: dict(v) for k, v in blank["per_alg"].items()} if blank["blank_set"] else {}
        bset = blank["blank_set"]
    single = c["optical_mode"] == "single"
    algs = {}
    results = {}
    for a in ALGS:
        res = PA.measurement_result(attempts, a, single)
        dual, sing = PA.od_values(res, bl.get(a), c["plf"]) if bset else (None, None)
        od = sing if single else dual
        results[a] = res
        algs[a] = {"od": None if od is None else round(od, 5), "rej": round(res["rej"], 1), "ok": res["ok"]}

    p = results[c["od_alg"]]
    pa = algs[c["od_alg"]]
    dual, sing = PA.od_values(p, bl.get(c["od_alg"]), c["plf"]) if bset else (None, None)
    hw_ok = any(att.get("hw_ok") for att in attempts)
    stuck = "".join(att.get("stuck", "") for att in attempts if att.get("stuck") not in (None, "-"))

    flags = []
    if p["sat_s"]: flags.append("sat_s")
    if p["sat_r"]: flags.append("sat_r")
    if p["low_s"]: flags.append("low_s")
    if p["low_r"]: flags.append("low_r")
    if not p["enough_s"]: flags.append("i2c_s")
    if not p["enough_r"]: flags.append("i2c_r")
    if "S" in stuck: flags.append("stuck_s")
    if "R" in stuck: flags.append("stuck_r")
    if pa["od"] is None: flags.append("no_od")
    if p["bubble"] > PA.REJECT_LIMIT_PCT: flags.append("bubbles")

    bv = blank_view(c["od_alg"])
    ref_rel = round(p["R"] / bv["r"], 4) if bset and bv["r"] > 0 and p["R"] > 0 else None
    sample_rel = round(p["S"] / bv["s"], 4) if bset and bv["s"] > 0 else None
    if not single and ref_rel is not None and not (REF_REL_BAND[0] <= ref_rel <= REF_REL_BAND[1]):
        flags.append("ref_drift")
    ok_sp, _ = splitter_check(bv["ratio"]) if bset else (None, None)
    if ok_sp is False:
        flags.append("split_ratio_off")
    if single:
        flags = [f for f in flags if f not in REF_FLAGS]
    valid = bool(p["ok"] and hw_ok and pa["od"] is not None)
    od = pa["od"]
    return {
        "od600": od, "od_dual": None if dual is None else round(dual, 5),
        "od_single": None if sing is None else round(sing, 5),
        "lux_s": round(p["S"], 3), "lux_r": round(p["R"], 3),
        "sr_ratio": None if single or p["R"] <= 0 else round(p["S"] / p["R"], 6),
        "counts_s": round(p["counts_s"], 1), "counts_r": round(p["counts_r"], 1),
        "fs_s": round(p["counts_s"] / FULL_SCALE, 4), "fs_r": round(p["counts_r"] / FULL_SCALE, 4),
        "bubble_pct": pa["rej"], "bubble_frac_pct": round(p["bubble"], 1), "valid": valid, "blank_set": bset,
        "ref_rel": None if single else ref_rel, "sample_rel": sample_rel,
        "transmittance_pct": round(100.0 * 10 ** (-od / c["plf"]), 3) if od is not None and c["plf"] > 0 else None,
        "flag_list": flags, "algs": algs, "od_alg": c["od_alg"], "optical_mode": c["optical_mode"],
        "attempts": len(attempts), "hw_ok": hw_ok,
    }


def push_od(client=None):
    with _lock:
        snap = dict(latest)
    snap["ref_rel_band"] = REF_REL_BAND
    snap["low_counts"] = PA.LOW_SIGNAL_COUNTS
    snap["splitter_expected"] = splitter_expected()
    send("od_update", snap, client)


def recompute_latest():
    """設定或 blank 改了: 用最後一筆原始讀值立刻重算目前顯示的值(不寫 CSV, 不加曲線點)。"""
    atts = list(_last_attempts)
    if not atts:
        return
    res = compute(atts)
    with _lock:
        latest.update(res)
    push_od()


_proc_lock = threading.RLock()     # Bridge notify 執行緒與輪詢執行緒可能同時送來同一次量測


def process_measurement(attempts, source):
    with _proc_lock:
        _process_measurement(attempts, source)


def _process_measurement(attempts, source):
    """收到一次完整量測(final): 計算、處理 blank、廣播、記錄、必要時要求重量。"""
    global _last_seen_seq, _blank_pending, _last_attempts, _retry_for_seq
    seq = attempts[-1]["seq"]
    if seq == _last_seen_seq:
        return
    _last_seen_seq = seq
    _last_attempts = list(attempts)

    if _blank_pending:
        _blank_pending = False
        set_blank_from(attempts)

    res = compute(attempts)
    now = time.time()
    with _lock:
        latest.update(res)
        latest.update({"ts": now, "meas_seq": seq, "age_s": 0.0, "busy": False})
        snap = dict(latest)
    point = {"t": round(now, 1), "od": snap["od600"], "od_dual": snap["od_dual"], "od_single": snap["od_single"],
             "ref_rel": snap["ref_rel"], "sample_rel": snap["sample_rel"], "valid": snap["valid"],
             "flags": snap["flag_list"], "alg": snap["od_alg"],
             "algs": {a: v["od"] for a, v in snap["algs"].items()},
             "algs_ok": {a: bool(v["ok"] and snap["hw_ok"] and v["od"] is not None) for a, v in snap["algs"].items()}}
    history.append(point)
    record_append(snap)
    send("history_point", point)
    push_od()
    od_txt = "--" if snap["od600"] is None else f"{snap['od600']:.4f}"
    others = " ".join(f"{a}={v['od']:.3f}" for a, v in snap["algs"].items() if v["od"] is not None and a != snap["od_alg"])
    print(f"[photo] seq={seq} OD={od_txt} [{snap['od_alg']}, {snap['optical_mode']}] S={snap['lux_s']:.1f}lx "
          f"R={snap['lux_r']:.1f}lx rej={snap['bubble_pct']:.0f}% bub={snap['bubble_frac_pct']:.0f}% valid={snap['valid']} "
          f"flags={','.join(snap['flag_list']) or '-'} | {others}")

    # 氣泡太多(氣泡比例或主要演算法拒收率 > 50%)→ 立刻再量一次; 連續兩次都太多就不再追
    too_many = max(snap["bubble_pct"], snap["bubble_frac_pct"]) > PA.REJECT_LIMIT_PCT
    if (BUBBLE_RETRY and source == "notify" and snap["blank_set"] and not snap["valid"]
            and too_many and _retry_for_seq != seq - 1):
        _retry_for_seq = seq
        print(f"[photo] seq={seq} 氣泡 {snap['bubble_frac_pct']:.0f}% / 拒收率 {snap['bubble_pct']:.0f}% → 立刻重量一次")
        _work_q.put((_retry_measure, ()))


def _retry_measure():
    try:
        bridge("trigger_measurement")
    except Exception:
        pass


def set_blank_from(attempts):
    """這次量測當成 blank: 每種演算法各自存自己的 S、R。飽和、讀取失敗、沒訊號就拒絕。"""
    single = cfg["optical_mode"] == "single"
    p = PA.measurement_result(attempts, cfg["od_alg"], single)
    hw_ok = any(att.get("hw_ok") for att in attempts)
    why = None
    if p["sat_s"] or (not single and p["sat_r"]):
        why = "saturated: reduce light (move fiber back / lower LED current)"
    elif not hw_ok or not p["enough_s"] or (not single and not p["enough_r"]):
        why = "sensor read failures"
    elif p["S"] <= 0 or (not single and p["R"] <= 0):
        why = "no signal: check LED / optical path"
    if why:
        print(f"[photo] blank REJECTED: {why}")
        send("blank_result", {"ok": False, "msg": why})
        return
    per = {}
    for a in ALGS:
        r = PA.measurement_result(attempts, a, single)
        per[a] = {"s": round(r["S"], 4), "r": round(r["R"], 4)}
    with _lock:
        blank.update({"blank_set": True, "per_alg": per, "at": time.time()})
    calib_save("blank", {"per_alg": per}, source="measured")
    print(f"[photo] blank set ({cfg['od_alg']}: S={per[cfg['od_alg']]['s']:.2f} lx, R={per[cfg['od_alg']]['r']:.2f} lx)")
    send("blank_result", {"ok": True, "msg": "blank set"})
    record_event("blank calibrated")
    push_blank()
    ok, rel = splitter_check(blank_view()["ratio"])
    if ok is False:
        print(f"[photo] !! 空白的 S/R 是分光比的 {rel}×(容許 ÷{SPLIT_TOL}~×{SPLIT_TOL}): 對光可能有問題")


def push_blank(client=None):
    b = blank_view()
    ok, rel = splitter_check(b["ratio"]) if b["blank_set"] else (None, None)
    with _lock:
        per = {a: dict(v) for a, v in blank["per_alg"].items()} if blank["blank_set"] else {}
        at = blank["at"]
    b.update({"splitter_ok": ok, "splitter_rel": rel, "splitter_expected": splitter_expected(), "at": at,
              "od_alg": cfg["od_alg"], "per_alg": per})
    send("blank_info", b, client)


def push_config(client=None):
    with _lock:
        c = dict(cfg)
    c["algorithms"] = [{"name": a, "label": PA.ALG_LABELS[a]} for a in ALGS]
    c["meas_duration_s"] = round((4 + 16) * c["period_ms"] / 1000.0 + 0.32, 1)
    c["splitter_expected"] = splitter_expected()
    c["splitter_tol"] = SPLIT_TOL
    c["sensor_label"] = f"MTreg {c['mt']} · H-res mode {2 if c['h2'] else 1} · {c['period_ms']} ms/read"
    send("config", c, client)


# ============================= MCU → Python =============================
N_DARK, N_LIT = 4, 16


def parse_raw_payload(payload):
    kv = parse_kv(payload)

    def vals(key, n):
        v = [int(_f(x, -1)) for x in kv.get(key, "").split("|") if x != ""]
        if len(v) != n:
            raise ValueError(f"{key} 有 {len(v)} 筆, 預期 {n}")
        return v

    return {
        "epoch_s": time.time(), "seq": int(_f(kv.get("seq"))), "att": int(_f(kv.get("att"))),
        "final": kv.get("final") == "1", "hw_ok": kv.get("hw_ok") == "1", "stuck": kv.get("stuck", "-"),
        "t0_ms": int(_f(kv.get("t0"))), "period_ms": int(_f(kv.get("per"))), "mtreg": int(_f(kv.get("mt"), 69)),
        "hres_mode": 2 if kv.get("h2") == "1" else 1, "lpc": _f(kv.get("lpc"), 0.416667),
        "ref_mode": int(_f(kv.get("ref_mode"))),
        "ds": vals("ds", N_DARK), "dr": vals("dr", N_DARK), "ls": vals("ls", N_LIT), "lr": vals("lr", N_LIT),
    }


def on_od_raw(payload):
    """Bridge 回呼: 只做計算與廣播, 絕不發同步 Bridge.call。"""
    try:
        att = parse_raw_payload(payload)
    except Exception as e:
        print(f"[raw] WARNING: 無法解析 on_od_raw ({e}): {str(payload)[:120]}")
        return
    att["blank_measure"] = 1 if _blank_pending else 0
    raw_append(att)
    lst = _pending_attempts.setdefault(att["seq"], [])
    lst.append(att)
    if att["final"]:
        _pending_attempts.pop(att["seq"], None)
        for k in [k for k in _pending_attempts if k < att["seq"] - 2 or k > att["seq"]]:
            _pending_attempts.pop(k, None)                   # MCU 重開後 seq 重來, 清掉殘留
        process_measurement(lst, "notify")


Bridge.provide("on_od_raw", on_od_raw)


def poll_raw_once():
    """保險用: 讀最近一次完成量測的 final 嘗試(漏收 notify 或 Python 剛重啟時)。"""
    try:
        r = bridge("get_last_raw")
        kv = parse_kv(r)
        busy = kv.get("busy") == "1"
        age = _f(kv.get("age_ms"), 0) / 1000.0
        with _lock:
            latest["busy"] = busy
            latest["age_s"] = round(age, 1)
        if not kv.get("seq"):
            return True                                       # 開機後還沒量過
        att = parse_raw_payload(r)
    except Exception as e:
        print(f"[photo] get_last_raw 失敗: {e}")
        return False
    if att["seq"] != _last_seen_seq:
        att["blank_measure"] = 0
        process_measurement([att], "poll")
        with _lock:
            latest["age_s"] = round(age, 1)
    return True


def refresh_config(client=None):
    try:
        kv = parse_kv(bridge("get_config"))
    except Exception:
        return False
    with _lock:
        cfg.update({"ref_mode": int(_f(kv.get("ref_mode"))), "mt": int(_f(kv.get("mt"), 69)),
                    "h2": int(_f(kv.get("h2"), 1)), "period_ms": int(_f(kv.get("period_ms"), 130)),
                    "lpc": _f(kv.get("lpc"), 0.416667)})
    push_config(client)
    return True


_mcu_uptime_ms = None
_last_i2c = None
I2C_HINT = {
    "timeout": "匯流排沒有回應 —— SDA(D20)/SCL(D21) 被拉低或短路、沒有上拉電阻、GY-302 沒供電或 GND 沒接",
    "nak": "匯流排正常但這個位址沒有裝置 —— 該顆 GY-302 沒供電, 或 ADDR 腳接錯(sample ADDR→3V3 = 0x5C, reference ADDR→GND = 0x23)",
}


def _check_i2c(i2c, force=False):
    global _last_i2c
    key = (i2c, cfg["optical_mode"])
    if key == _last_i2c and not force:
        return
    _last_i2c = key
    parts = dict(x.split(":", 1) for x in i2c.split("|") if ":" in x)
    chans = [("S", "Sample", "0x5C")] + ([] if cfg["optical_mode"] == "single" else [("R", "Reference", "0x23")])
    msgs = []
    for k, name, addr in chans:
        st = parts.get(k, "?")
        if st not in ("ok", "?"):
            msgs.append(f"{name} {addr}: {st} —— {I2C_HINT.get(st, 'I2C 錯誤')}")
    warn = ("開機時 I2C 探測失敗(修好接線後 MCU 會自動重試初始化, 不必重開): " + "; ".join(msgs)) if msgs else None
    with _link_lock:
        mcu_link["warn"] = warn
    if warn:
        print(f"[mcu] !! {warn}")
    send("mcu_link", _link_snapshot())


_last_rc = None


def _note_reinit(rc):
    global _last_rc
    if not rc or rc == _last_rc:
        return
    prev, _last_rc = _last_rc, rc
    cnt = {k: int(_f(v)) for k, v in (x.split(":", 1) for x in rc.split("|") if ":" in x)}
    with _link_lock:
        mcu_link["reinit"] = cnt
    if prev is not None:
        old = {k: int(_f(v)) for k, v in (x.split(":", 1) for x in prev.split("|") if ":" in x)}
        if any(cnt.get(k, 0) > old.get(k, 0) for k in cnt):
            print(f"[mcu] 感測器自動重新初始化: {prev} → {rc}")
            record_event(f"sensor reinit {rc}")
    send("mcu_link", _link_snapshot())


_last_io = None


def _note_io(io):
    global _last_io
    if not io or io == _last_io:
        return
    prev, _last_io = _last_io, io
    out = {}
    for part in io.split("|"):
        if ":" in part:
            k, v = part.split(":", 1)
            nums = [int(_f(x)) for x in v.split("/")] + [0, 0, 0]
            out[k] = {"slow": nums[0], "blocked": nums[1], "fail": nums[2]}
    with _link_lock:
        old = mcu_link.get("io") or {}
        mcu_link["io"] = out
    if prev is not None:
        for k, v in out.items():
            if v["blocked"] > (old.get(k) or {}).get("blocked", 0):
                name = "sample" if k == "S" else "reference"
                print(f"[mcu] !! {name} 感測器 I2C 連續變慢, 暫停 2 秒 (累計 {v})")
                record_event(f"I2C {name} paused 2 s (slow={v['slow']} paused={v['blocked']} fail={v['fail']})")
    send("mcu_link", _link_snapshot())


def poll_diag():
    global _mcu_uptime_ms
    try:
        p = [x.strip() for x in bridge("get_diag").split(",")]
        fw = p[-1] if p and not p[-1].replace(".", "").isdigit() else "?(舊版 sketch, 沒有版本號)"
        if fw != EXPECTED_FW:
            print(f"[mcu] !! MCU 上跑的是「{fw}」, 不是 {EXPECTED_FW} —— 請重新上傳 photometer 的 sketch")
            _set_mcu_link(True, fw=fw)
            return
        uptime = int(_f(p[3]))
        with _link_lock:
            mcu_link["loop_max_ms"] = round(_f(p[0]) / 1000.0, 1)
        stage = p[4] if len(p) >= 6 else "ready"
        _check_i2c(next((x[4:] for x in p if x.startswith("i2c=")), ""))
        _note_reinit(next((x[3:] for x in p if x.startswith("rc=")), ""))
        _note_io(next((x[3:] for x in p if x.startswith("io=")), ""))
        if stage != "ready":
            hint = {"i2c_scan": "I2C 匯流排卡住: 檢查 SDA(D20)/SCL(D21) 有沒有短路或被拉低、GY-302 供電",
                    "sensor_init": "BH1750 初始化中卡住: 檢查兩顆 GY-302 的接線與位址",
                    "register": "註冊 Bridge 函式時卡住"}.get(stage, "")
            with _link_lock:
                mcu_link["fw"] = fw
            _set_mcu_link(False, f"MCU sketch 已啟動({fw}), 但卡在開機步驟「{stage}」。{hint}")
            return
    except Exception:
        return
    _set_mcu_link(True, fw=fw)
    prev = _mcu_uptime_ms
    _mcu_uptime_ms = uptime
    if prev is not None and uptime < prev:
        print(f"[mcu] 偵測到 MCU 重開(uptime {prev} → {uptime} ms), 重新推送量測間隔與光路模式")
        push_config_to_mcu()
        record_event("MCU rebooted")
        send("mcu_rebooted", {"ts": time.time()})


# ============================= 存檔(Linux 端) =============================
# calibration_state.json:
#   config → 量測間隔、光程長係數、主要演算法、光路模式、分光比
#   blank  → 每種演算法各自的 {s, r, ratio}; 來源 measured / manual(manual 會持續黃色提示)
# v1.2.0 起 blank 不在 MCU 上, MCU 重開也不會遺失。
_calib_lock = threading.Lock()
calib = {"items": {}, "source": {}}


def _calib_load():
    try:
        with open(CALIB_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return
        items = dict(data.get("items") or {})
        items.pop("gains", None)
        source = {k: v for k, v in dict(data.get("source") or {}).items() if k != "gains"}
        b = items.get("blank")
        if isinstance(b, dict) and "per_alg" not in b:
            # v1.1.x 的 blank 只有一組值 → 套用到全部演算法, 並標成「手動」提醒重新校正
            items["blank"] = {"per_alg": {a: {"s": b.get("s") or 0.0, "r": b.get("r") or 0.0,
                                              "ratio": b.get("ratio") or 0.0} for a in ALGS},
                              "saved_at": b.get("saved_at")}
            source["blank"] = {"source": "manual", "at": time.time()}
        calib["items"] = items
        calib["source"] = source
        print(f"[calib] 已載入存檔: {', '.join(sorted(calib['items'])) or '(空)'}")
    except FileNotFoundError:
        pass
    except (OSError, json.JSONDecodeError) as e:
        print(f"[calib] 讀取 {CALIB_PATH} 失敗({e}), 當作沒有存檔")


def _calib_write():
    tmp = CALIB_PATH + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"saved_at": time.time(), "items": calib["items"], "source": calib["source"]},
                      f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, CALIB_PATH)
    except OSError as e:
        print(f"[calib] 寫入失敗: {e}")


def calib_save(item, value, source):
    with _calib_lock:
        if value is None:
            calib["items"].pop(item, None)
            calib["source"].pop(item, None)
        else:
            calib["items"][item] = dict(value, saved_at=time.time())
            calib["source"][item] = {"source": source, "at": time.time()}
        _calib_write()
    push_calib_state()


def push_calib_state(client=None):
    with _calib_lock:
        items = json.loads(json.dumps(calib["items"]))
        source = json.loads(json.dumps(calib["source"]))
    attention = [k for k in ("blank",) if source.get(k, {}).get("source") == "manual"]
    send("calib_state", {"items": items, "source": source, "needs_attention": attention,
                         "file": CALIB_PATH}, client)


def save_config():
    with _lock:
        c = {k: cfg[k] for k in ("interval_s", "plf", "od_alg", "optical_mode", "split_s", "split_r")}
    calib_save("config", c, source="measured")


def load_saved_state():
    with _calib_lock:
        c = dict(calib["items"].get("config") or {})
        b = calib["items"].get("blank")
    with _lock:
        for k in ("interval_s", "plf", "split_s", "split_r"):
            if k in c:
                cfg[k] = float(c[k])
        if "od_alg" in c:
            cfg["od_alg"] = alg_name(c["od_alg"])
        if c.get("optical_mode") in OPTICAL_MODES:
            cfg["optical_mode"] = c["optical_mode"]
        elif "ref_mode" in c:
            cfg["optical_mode"] = "single" if int(c["ref_mode"]) == 1 else "fiber"
        if b and b.get("per_alg"):
            blank.update({"blank_set": True, "per_alg": {a: dict(v) for a, v in b["per_alg"].items()},
                          "at": b.get("saved_at")})


def push_config_to_mcu():
    with _lock:
        c = dict(cfg)
    try:
        r = bridge("set_config", f"interval_s={c['interval_s']},ref_mode={ref_mode_for(c['optical_mode'])}")
        if r.startswith("rejected"):
            raise ValueError(r)
        return True
    except Exception as e:
        print(f"[config] 推送設定給 MCU 失敗: {e}")
        return False


_startup_done = False


def startup_sync():
    global _startup_done
    if _startup_done:
        return True
    poll_diag()
    if not push_config_to_mcu():
        print("[startup] MCU 還沒就緒, 稍後重試")
        return False
    refresh_config()
    poll_raw_once()
    push_blank()
    push_od()
    _startup_done = True
    print(f"[startup] 完成: 主要演算法 {cfg['od_alg']}, 光路 {cfg['optical_mode']}, "
          f"blank {'已設定' if blank['blank_set'] else '未設定'}")
    return True


# ============================= 背景輪詢 =============================
def poll_loop():
    global dev_mode, _dev_last_poll
    while True:
        time.sleep(POLL_INTERVAL_SEC)
        if not _startup_done:
            startup_sync()
            continue
        poll_diag()
        if dev_mode and _dev_last_poll is not None and time.time() - _dev_last_poll > DEV_TIMEOUT_SEC:
            try:
                bridge("set_dev_mode", "0")
                dev_mode = False
                _dev_last_poll = None
                print(f"[align] 超過 {DEV_TIMEOUT_SEC:.0f} 秒沒有瀏覽器活動, 自動關閉對光模式")
                record_event("alignment mode auto-off")
                send("dev_status", {"dev_mode": False, "auto_off": True})
            except Exception as e:
                print(f"[align] 自動關閉失敗, 下次再試: {e}")
        if dev_mode:
            continue
        if poll_raw_once():
            push_od()
        record_tick()


# ============================= 網頁指令 =============================
@on_ui("get_state")
def h_get_state(client, data):
    send("mcu_link", _link_snapshot(), client)
    push_config(client)
    push_blank(client)
    push_od(client)
    push_calib_state(client)
    send("dev_status", {"dev_mode": dev_mode}, client)
    send("history", {"points": list(history), "now": time.time()}, client)
    push_record_status(client)
    send("recordings_list", {"files": list_recordings()}, client)


@on_ui("measure_now")
def h_measure_now(client, data):
    try:
        r = bridge("trigger_measurement")
        action_result(client, "measure_now", r == "queued", None if r == "queued" else r)
    except Exception as e:
        action_result(client, "measure_now", False, str(e))


@on_ui("calibrate_blank")
def h_calibrate_blank(client, data):
    """下一次完成的量測當成 blank(正在量的話就用這一次)。"""
    global _blank_pending
    if dev_mode:
        action_result(client, "calibrate_blank", False, "busy")
        return
    _blank_pending = True
    try:
        bridge("trigger_measurement")
    except Exception as e:
        _blank_pending = False
        action_result(client, "calibrate_blank", False, str(e))
        return
    action_result(client, "calibrate_blank", True)


@on_ui("set_config")
def h_set_config(client, data):
    with _lock:
        before = dict(cfg)
    new = {k: before[k] for k in ("interval_s", "plf", "od_alg", "optical_mode", "split_s", "split_r")}
    try:
        for k in ("interval_s", "plf", "split_s", "split_r"):
            if data.get(k) not in (None, ""):
                new[k] = float(data[k])
        if data.get("od_alg") not in (None, ""):
            if data["od_alg"] not in ALGS:
                raise ValueError(f"od_alg must be one of {ALGS}")
            new["od_alg"] = data["od_alg"]
        if data.get("optical_mode") not in (None, ""):
            if data["optical_mode"] not in OPTICAL_MODES:
                raise ValueError(f"optical_mode must be one of {OPTICAL_MODES}")
            new["optical_mode"] = data["optical_mode"]
        if not (5 <= new["interval_s"] <= 86400):
            raise ValueError("interval 5-86400 s")
        if not (0 < new["plf"] <= 1000):
            raise ValueError("path-length factor (0, 1000]")
        if new["optical_mode"] == "splitter" and not (new["split_s"] > 0 and new["split_r"] > 0):
            raise ValueError("splitter ratio: both parts must be > 0")
    except (TypeError, ValueError) as e:
        action_result(client, "set_config", False, str(e))
        return
    with _lock:
        cfg.update(new)
    if (new["interval_s"] != before["interval_s"] or new["optical_mode"] != before["optical_mode"]) \
            and not push_config_to_mcu():
        with _lock:
            cfg.update({k: before[k] for k in new})
        action_result(client, "set_config", False, "MCU did not accept the setting")
        return
    refresh_config()
    save_config()
    changes = [f"{k}={new[k]}" for k in new if before.get(k) != new[k]]
    if changes:
        record_event("config " + " ".join(changes))
    if new["optical_mode"] != before["optical_mode"] and _last_i2c:
        _check_i2c(_last_i2c[0], force=True)
    push_blank()
    recompute_latest()
    action_result(client, "set_config", True)


@on_ui("set_blank_manual")
def h_set_blank_manual(client, data):
    ratio, s, r = _f(data.get("ratio")), _f(data.get("s")), _f(data.get("r"))
    if ratio <= 0 and s > 0 and r > 0:
        ratio = s / r
    if ratio <= 0 and s <= 0:
        action_result(client, "set_blank_manual", False, "need ratio > 0, or sample (and reference) lux > 0")
        return
    per = {a: {"s": s, "r": r, "ratio": ratio} for a in ALGS}
    with _lock:
        blank.update({"blank_set": True, "per_alg": per, "at": time.time()})
    calib_save("blank", {"per_alg": per}, source="manual")
    record_event("blank set manually")
    push_blank()
    recompute_latest()
    action_result(client, "set_blank_manual", True)


@on_ui("clear_blank")
def h_clear_blank(client, data):
    with _lock:
        blank.update({"blank_set": False, "per_alg": {}, "at": None})
    calib_save("blank", None, source=None)
    record_event("blank cleared")
    push_blank()
    recompute_latest()
    action_result(client, "clear_blank", True)


@on_ui("set_dev_mode")
def h_set_dev_mode(client, data):
    global dev_mode, _dev_last_poll
    on = bool(data.get("on"))
    try:
        bridge("set_dev_mode", "1" if on else "0")
    except Exception as e:
        send("dev_status", {"dev_mode": dev_mode, "error": str(e)}, client)
        return
    dev_mode = on
    _dev_last_poll = time.time() if on else None
    record_event("alignment mode on" if on else "alignment mode off")
    send("dev_status", {"dev_mode": dev_mode})


@on_ui("reinit_sensors")
def h_reinit_sensors(client, data):
    try:
        r = bridge("reinit_sensors")
    except Exception as e:
        action_result(client, "reinit_sensors", False, str(e))
        return
    ok = r != "busy"
    if ok:
        record_event(f"manual sensor reinit {r}")
    action_result(client, "reinit_sensors", ok, None if ok else "busy", result=r)


@on_ui("get_dev_readings")
def h_get_dev_readings(client, data):
    global _dev_last_poll
    if not dev_mode:
        send("dev_readings", {"dev_mode": False}, client)
        return
    _dev_last_poll = time.time()
    try:
        p = bridge("get_dev_readings").split(",")
        raw_s, raw_r, lux_s, lux_r = _f(p[1], -1), _f(p[2], -1), _f(p[3], -1), _f(p[4], -1)
    except Exception as e:
        send("dev_readings", {"dev_mode": True, "error": str(e)}, client)
        return
    b = blank_view()
    sr = round(lux_s / lux_r, 5) if lux_s >= 0 and lux_r > 1e-6 else None
    sp_ok, sp_rel = splitter_check(sr)
    send("dev_readings", {
        "dev_mode": True, "optical_mode": cfg["optical_mode"],
        "raw_s": raw_s, "raw_r": raw_r,
        "lux_s": None if lux_s < 0 else round(lux_s, 3), "lux_r": None if lux_r < 0 else round(lux_r, 3),
        "fs_s": None if raw_s < 0 else round(raw_s / FULL_SCALE, 4),
        "fs_r": None if raw_r < 0 else round(raw_r / FULL_SCALE, 4),
        "sr_ratio": sr, "blank_ratio": b["ratio"] if b["blank_set"] and b["ratio"] > 0 else None,
        "splitter_expected": splitter_expected(), "splitter_ok": sp_ok, "splitter_rel": sp_rel,
        "low_counts": PA.LOW_SIGNAL_COUNTS,
    }, client)


# ============================= CSV 錄製 =============================
# <名>.csv:     每次量測一列(主要演算法的結果 + 8 種演算法各自的 OD 與拒收率)
# <名>_raw.csv: 每次嘗試一列(全部原始讀值; tools/replay.py 用)
CSV_HEADER = ([
    "timestamp_iso", "epoch_s", "elapsed_s", "dt_s", "meas_seq", "attempts",
    "od600", "od_dual", "od_single", "od_alg", "optical_mode", "splitter_ratio", "transmittance_pct",
    "lux_sample", "lux_ref", "sr_ratio", "blank_ratio", "blank_lux_sample", "blank_lux_ref",
    "ref_rel", "sample_rel", "counts_sample", "counts_ref",
    "bubble_pct", "bubble_frac_pct", "valid", "blank_set", "flag_text", "path_length_factor"]
    + [f"od_{a}" for a in ALGS] + [f"rej_{a}" for a in ALGS] + ["event"])
RAW_HEADER = (["timestamp_iso", "epoch_s", "meas_seq", "attempt", "final", "hw_ok", "stuck", "blank_measure",
               "t0_ms", "period_ms", "mtreg", "hres_mode", "lux_per_count", "ref_mode", "optical_mode"]
              + [f"dark_s_{i}" for i in range(N_DARK)] + [f"dark_r_{i}" for i in range(N_DARK)]
              + [f"lit_s_{i}" for i in range(N_LIT)] + [f"lit_r_{i}" for i in range(N_LIT)])

_rec_lock = threading.Lock()
rec = {"active": False, "file": None, "raw_file": None, "started_at": None, "duration_sec": None,
       "rows": 0, "raw_rows": 0, "last_row_at": None, "label": ""}
_pending_events = []
_last_blank_raw = []


def _raw_row(att):
    return ([datetime.fromtimestamp(att["epoch_s"]).isoformat(timespec="seconds"), f"{att['epoch_s']:.2f}",
             att["seq"], att["att"], int(att["final"]), int(att["hw_ok"]), att["stuck"], att.get("blank_measure", 0),
             att["t0_ms"], att["period_ms"], att["mtreg"], att["hres_mode"], f"{att['lpc']:.6f}", att["ref_mode"],
             att.get("optical_mode", "")]
            + att["ds"] + att["dr"] + att["ls"] + att["lr"])


def _append_csv(path, row):
    with open(path, "a", encoding="utf-8", newline="") as f:
        csv.writer(f).writerow(row)
        f.flush()
        os.fsync(f.fileno())


def raw_append(att):
    global _last_blank_raw
    att["optical_mode"] = cfg["optical_mode"]
    if att.get("blank_measure"):
        if att["att"] == 0:
            _last_blank_raw = []
        _last_blank_raw.append(att)
    with _rec_lock:
        if not rec["active"] or not rec.get("raw_file"):
            return
        try:
            _append_csv(os.path.join(RECORDINGS_DIR, rec["raw_file"]), _raw_row(att))
            rec["raw_rows"] = rec.get("raw_rows", 0) + 1
        except OSError as e:
            print(f"[record] raw 寫入失敗: {e}")


def _rec_state_write():
    try:
        with open(RECORD_STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(rec, f)
    except OSError as e:
        print(f"[record] 寫入 recording_state.json 失敗: {e}")


def record_event(text):
    with _rec_lock:
        if rec["active"]:
            _pending_events.append(text)


def _fmt(v, nd=None):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "1" if v else "0"
    if nd is not None and isinstance(v, (int, float)):
        return f"{v:.{nd}f}"
    return str(v)


def record_append(snap):
    with _rec_lock:
        if not rec["active"]:
            return
        now = snap["ts"]
        with _lock:
            c = dict(cfg)
        b = blank_view(c["od_alg"])
        events = "; ".join(_pending_events)
        _pending_events.clear()
        sp = f"{c['split_s']:g}:{c['split_r']:g}" if c["optical_mode"] == "splitter" else ""
        row = ([
            datetime.fromtimestamp(now).isoformat(timespec="seconds"), _fmt(now, 1),
            _fmt(now - rec["started_at"], 1),
            _fmt(now - rec["last_row_at"], 1) if rec["last_row_at"] else "",
            snap["meas_seq"], snap.get("attempts", 1),
            _fmt(snap["od600"], 5), _fmt(snap["od_dual"], 5), _fmt(snap["od_single"], 5),
            c["od_alg"], c["optical_mode"], sp, _fmt(snap["transmittance_pct"], 3),
            _fmt(snap["lux_s"], 3), _fmt(snap["lux_r"], 3), _fmt(snap["sr_ratio"], 6),
            _fmt(b["ratio"] if b["blank_set"] else None, 6),
            _fmt(b["s"] if b["blank_set"] else None, 3), _fmt(b["r"] if b["blank_set"] else None, 3),
            _fmt(snap["ref_rel"], 4), _fmt(snap["sample_rel"], 4),
            _fmt(snap["counts_s"], 0), _fmt(snap["counts_r"], 0),
            _fmt(snap["bubble_pct"], 1), _fmt(snap["bubble_frac_pct"], 1), _fmt(snap["valid"]), _fmt(snap["blank_set"]),
            "|".join(snap["flag_list"]), _fmt(c["plf"], 4)]
            + [_fmt(snap["algs"][a]["od"], 5) for a in ALGS]
            + [_fmt(snap["algs"][a]["rej"], 1) for a in ALGS]
            + [events])
        try:
            _append_csv(os.path.join(RECORDINGS_DIR, rec["file"]), row)
        except OSError as e:
            print(f"[record] 寫入失敗: {e}")
            send("record_error", {"error": str(e)})
            return
        rec["rows"] += 1
        rec["last_row_at"] = now
        _rec_state_write()
    push_record_status()


def push_record_status(client=None):
    with _rec_lock:
        r = dict(rec)
    r["elapsed_sec"] = (time.time() - r["started_at"]) if r["active"] and r["started_at"] else 0
    r["download_url"] = f"/download/recording?name={r['file']}" if r["file"] else None
    send("record_status", r, client)


def _finish_record(auto=False):
    with _rec_lock:
        if not rec["active"]:
            return None
        rec["active"] = False
        info = {"filename": rec["file"], "raw_filename": rec.get("raw_file"), "rows": rec["rows"],
                "raw_rows": rec.get("raw_rows", 0), "auto": auto,
                "elapsed_sec": time.time() - rec["started_at"],
                "download_url": f"/download/recording?name={rec['file']}"}
        _rec_state_write()
    print(f"[record] 停止: {info['filename']} ({info['rows']} 列) + {info['raw_filename']} ({info['raw_rows']} 列)")
    send("record_saved", info)
    push_record_status()
    send("recordings_list", {"files": list_recordings()})
    return info


def record_tick():
    with _rec_lock:
        active, started, dur = rec["active"], rec["started_at"], rec["duration_sec"]
    if active and dur and time.time() - started >= dur:
        _finish_record(auto=True)
    elif active:
        push_record_status()


@on_ui("start_record")
def h_start_record(client, data):
    with _rec_lock:
        if rec["active"]:
            action_result(client, "start_record", False, "already recording")
            return
    dur = _f(data.get("duration_sec"), 0) or None
    label = "".join(ch for ch in str(data.get("label") or "") if ch.isalnum() or ch in "-_")[:40]
    base = "photometer_" + datetime.now().strftime("%Y%m%d_%H%M%S") + (f"_{label}" if label else "")
    name, raw_name = base + ".csv", base + "_raw.csv"
    try:
        for fn, header in ((name, CSV_HEADER), (raw_name, RAW_HEADER)):
            with open(os.path.join(RECORDINGS_DIR, fn), "w", encoding="utf-8", newline="") as f:
                csv.writer(f).writerow(header)
                f.flush()
                os.fsync(f.fileno())
        for att in _last_blank_raw:
            _append_csv(os.path.join(RECORDINGS_DIR, raw_name), _raw_row(att))
    except OSError as e:
        action_result(client, "start_record", False, str(e))
        return
    with _lock:
        c = dict(cfg)
    with _rec_lock:
        rec.update({"active": True, "file": name, "raw_file": raw_name, "started_at": time.time(),
                    "duration_sec": dur, "rows": 0, "raw_rows": len(_last_blank_raw),
                    "last_row_at": None, "label": label})
        _pending_events.clear()
        _pending_events.append(
            f"start; optical={c['optical_mode']}"
            + (f" {c['split_s']:g}:{c['split_r']:g}" if c["optical_mode"] == "splitter" else "")
            + f"; primary alg={c['od_alg']}; sensor MTreg{c['mt']}/H{2 if c['h2'] else 1}"
            + f"; blank={'set' if blank['blank_set'] else 'NOT SET'}; blank raw rows={len(_last_blank_raw)}"
            + f"; fw={mcu_link.get('fw')}; py={BACKEND_VERSION}")
        _rec_state_write()
    print(f"[record] 開始: {name} + {raw_name}" + (f"(定時 {dur:.0f} 秒)" if dur else ""))
    action_result(client, "start_record", True)
    push_record_status()
    send("recordings_list", {"files": list_recordings()})


@on_ui("stop_record")
def h_stop_record(client, data):
    info = _finish_record(auto=False)
    action_result(client, "stop_record", info is not None, None if info else "not recording")


@on_ui("add_note")
def h_add_note(client, data):
    text = str(data.get("text") or "").replace("\n", " ").strip()[:200]
    if not text:
        action_result(client, "add_note", False, "empty")
        return
    with _rec_lock:
        active = rec["active"]
    if not active:
        action_result(client, "add_note", False, "not recording")
        return
    record_event("note: " + text)
    action_result(client, "add_note", True)


def list_recordings():
    out = []
    try:
        with _rec_lock:
            active = {rec["file"], rec.get("raw_file")} if rec["active"] else set()
        for name in sorted(os.listdir(RECORDINGS_DIR), reverse=True):
            if not name.endswith(".csv"):
                continue
            st = os.stat(os.path.join(RECORDINGS_DIR, name))
            out.append({"name": name, "size_bytes": st.st_size, "modified_at": st.st_mtime,
                        "active": name in active, "raw": name.endswith("_raw.csv"),
                        "download_url": f"/download/recording?name={name}"})
    except OSError as e:
        print(f"[record] 列出檔案失敗: {e}")
    return out[:200]


@on_ui("list_recordings")
def h_list_recordings(client, data):
    send("recordings_list", {"files": list_recordings()}, client)


def _header_of(name):
    try:
        with open(os.path.join(RECORDINGS_DIR, os.path.basename(name)), "r", encoding="utf-8") as f:
            return next(csv.reader(f), None)
    except OSError:
        return None


def resume_recording():
    try:
        with open(RECORD_STATE_PATH, "r", encoding="utf-8") as f:
            st = json.load(f)
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return
    if not st.get("active") or not st.get("file"):
        return
    if _header_of(st["file"]) != CSV_HEADER or (st.get("raw_file") and _header_of(st["raw_file"]) != RAW_HEADER):
        print(f"[record] 無法接續 {st['file']}(檔案不存在或欄位格式不同, 可能是舊版錄的), 放棄接續")
        st["active"] = False
        rec.update(st)
        _rec_state_write()
        return
    rec.update(st)
    _pending_events.append("resumed after app/board restart")
    print(f"[record] 接續中斷的錄製: {st['file']}(已有 {st.get('rows', 0)} 列)")


def _register_download_endpoint():
    if not hasattr(ui, "expose_api"):
        print(f"[record] 這個 WebUI Brick 沒有 expose_api, 略過下載端點; 檔案在 {RECORDINGS_DIR}")
        return
    try:
        from fastapi.responses import FileResponse, JSONResponse
    except ImportError:
        print("[record] 找不到 fastapi, 略過下載端點")
        return

    def api_download_recording(name: str = None):
        safe = os.path.basename(name or "")
        full = os.path.join(RECORDINGS_DIR, safe)
        if not safe.endswith(".csv") or not os.path.exists(full):
            return JSONResponse({"error": "not found"}, status_code=404)
        return FileResponse(full, filename=safe, media_type="text/csv")

    def api_list_recordings():
        return {"files": list_recordings()}

    try:
        ui.expose_api("GET", "/download/recording", api_download_recording)
        ui.expose_api("GET", "/api/recordings", api_list_recordings)
        print("[record] 下載端點 /download/recording 已註冊")
    except Exception as e:
        print(f"[record] 註冊下載端點失敗(不影響錄製): {e}")


# ============================= 啟動 =============================
def _run_forever(name, fn):
    def runner():
        while True:
            try:
                fn()
            except Exception:
                print(f"[thread] {name} 例外, 1 秒後重啟:\n{traceback.format_exc()}")
            time.sleep(1.0)
    return runner


def _startup_then_poll():
    for _ in range(60):
        if startup_sync():
            break
        time.sleep(2)
    poll_loop()


_calib_load()
load_saved_state()
resume_recording()
_register_download_endpoint()
print(f"[boot] {BACKEND_VERSION}, constants={CONST['config_version']}, optical={cfg['optical_mode']}, "
      f"primary alg={cfg['od_alg']}, blank={'set' if blank['blank_set'] else 'not set'}, recordings → {RECORDINGS_DIR}")

threading.Thread(target=_run_forever("worker", _worker), daemon=True, name="worker").start()
threading.Thread(target=_run_forever("poll_loop", _startup_then_poll), daemon=True, name="poll_loop").start()

App.run()
